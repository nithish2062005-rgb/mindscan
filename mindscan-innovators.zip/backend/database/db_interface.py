from abc import ABC, abstractmethod

class DatabaseInterface(ABC):
    
    @abstractmethod
    def save_user(self, name, email, hashed_password, role):
        """Save a new user (student, counselor, admin) to the database."""
        pass
        
    @abstractmethod
    def get_user_by_email(self, email):
        """Retrieve user details by email."""
        pass

    @abstractmethod
    def get_user_by_id(self, user_id):
        """Retrieve user details by user ID."""
        pass
        
    @abstractmethod
    def save_survey(self, user_id, survey_type, answers, score):
        """Save survey scores and answers (PHQ-9, GAD-7, PSS)."""
        pass
        
    @abstractmethod
    def get_surveys_by_user(self, user_id):
        """Retrieve all survey records completed by a specific user."""
        pass
        
    @abstractmethod
    def save_mood(self, user_id, mood, stress_score, note):
        """Save daily mood tracking logs."""
        pass
        
    @abstractmethod
    def get_mood_history(self, user_id):
        """Retrieve mood tracking history for a specific user."""
        pass
        
    @abstractmethod
    def save_appointment(self, student_id, counselor_id, date, time_slot):
        """Book a session with a counselor."""
        pass
        
    @abstractmethod
    def get_appointments_by_user(self, user_id, role):
        """Retrieve appointment schedule for a student or counselor."""
        pass
        
    @abstractmethod
    def update_appointment_status(self, appointment_id, status):
        """Update appointment status (Pending, Approved, Completed)."""
        pass
        
    @abstractmethod
    def get_admin_analytics(self):
        """Fetch global analytics and telemetry for the admin dashboard."""
        pass
