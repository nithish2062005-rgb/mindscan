from flask import Blueprint, request, jsonify
from database import get_db
from services.security import hash_password, check_password, generate_token

auth_bp = Blueprint('auth', __name__)

@auth_bp.route('/signup', methods=['POST'])
def signup():
    data = request.get_json() or {}
    name = data.get('name')
    email = data.get('email')
    password = data.get('password')
    role = data.get('role', 'student') # Default role is student

    if not name or not email or not password:
        return jsonify({'message': 'Missing required fields: name, email, password'}), 400

    if role not in ('student', 'counselor', 'admin'):
        return jsonify({'message': 'Invalid role specified. Must be student, counselor, or admin'}), 400

    db = get_db()
    # Check if user already exists
    existing = db.get_user_by_email(email)
    if existing:
        return jsonify({'message': 'User with this email already exists'}), 409

    # Hash the password
    hashed_pwd = hash_password(password)
    
    try:
        user = db.save_user(name, email, hashed_pwd, role)
        return jsonify({
            'message': 'User registered successfully',
            'user': user
        }), 201
    except Exception as e:
        return jsonify({'message': 'Failed to register user', 'error': str(e)}), 500


@auth_bp.route('/login', methods=['POST'])
def login():
    data = request.get_json() or {}
    email = data.get('email')
    password = data.get('password')

    if not email or not password:
        return jsonify({'message': 'Missing required fields: email, password'}), 400

    db = get_db()
    user = db.get_user_by_email(email)
    if not user or not check_password(password, user['password']):
        return jsonify({'message': 'Invalid email or password'}), 401

    # Generate token
    token = generate_token(user['id'], user['role'])

    return jsonify({
        'message': 'Login successful',
        'token': token,
        'user': {
            'id': user['id'],
            'name': user['name'],
            'email': user['email'],
            'role': user['role']
        }
    }), 200


@auth_bp.route('/reset-password', methods=['POST'])
def reset_password():
    data = request.get_json() or {}
    email = data.get('email')
    
    if not email:
        return jsonify({'message': 'Email address is required'}), 400
        
    db = get_db()
    user = db.get_user_by_email(email)
    if not user:
        # Avoid user enumeration by returning 200 anyway
        return jsonify({'message': 'If this email is registered, a password reset link has been simulated.'}), 200

    # In a real app, send reset link. Here we just return mock success
    return jsonify({
        'message': 'Password reset request processed. A password reset link has been simulated.',
        'email': email
    }), 200


@auth_bp.route('/google-login', methods=['POST'])
def google_login():
    data = request.get_json() or {}
    token = data.get('credential')

    if not token:
        return jsonify({'message': 'Missing Google credential token'}), 400

    db = get_db()
    try:
        if isinstance(token, str) and token.startswith('mock_google_token_'):
            # Mock validation for automated tests and offline simulation
            parts = token.split('_')
            email = parts[-1] if len(parts) > 2 else "mockuser@university.edu"
            name = email.split('@')[0].replace('.', ' ').title()
        else:
            from google.oauth2 import id_token
            from google.auth.transport import requests as google_requests
            
            # Verify the ID Token with Google APIs
            idinfo = id_token.verify_oauth2_token(token, google_requests.Request())
            email = idinfo.get('email')
            name = idinfo.get('name', 'Google User')
        
        if not email:
            return jsonify({'message': 'Invalid Google token: email not provided'}), 400

        # Check if user exists
        user = db.get_user_by_email(email)
        if not user:
            # Auto-register Google users as students
            import uuid
            import bcrypt
            random_pw = str(uuid.uuid4())
            salt = bcrypt.gensalt(rounds=12)
            hashed_pwd = bcrypt.hashpw(random_pw.encode('utf-8'), salt).decode('utf-8')
            
            user = db.save_user(name, email, hashed_pwd, 'student')
            print(f"Auto-registered Google user: {email} (Student)")

        # Generate JWT session token
        session_token = generate_token(user['id'], user['role'])

        return jsonify({
            'message': 'Google login successful',
            'token': session_token,
            'user': {
                'id': user['id'],
                'name': user['name'],
                'email': user['email'],
                'role': user['role']
            }
        }), 200

    except ValueError as e:
        return jsonify({'message': 'Invalid Google token credentials', 'error': str(e)}), 401
    except Exception as e:
        return jsonify({'message': 'Google login verification failed', 'error': str(e)}), 500

