from flask import Blueprint, request, jsonify
from database import get_db
from services.security import token_required

appointment_bp = Blueprint('appointment', __name__)

@appointment_bp.route('/appointment', methods=['POST'])
@token_required
def create_appointment(current_user):
    data = request.get_json() or {}
    counselor_id = data.get('counselor_id')
    date = data.get('date')
    time_slot = data.get('time') # Slot: e.g. "Monday at 09:00 AM IST"

    if not counselor_id or not date or not time_slot:
        return jsonify({'message': 'Missing required fields: counselor_id, date, time'}), 400

    db = get_db()
    
    # Verify counselor exists and is actually a counselor or admin
    counselor = db.get_user_by_id(counselor_id)
    if not counselor or counselor['role'] not in ('counselor', 'admin'):
        return jsonify({'message': 'Invalid counselor_id. Recipient must be a registered Counselor.'}), 400

    try:
        appt = db.save_appointment(current_user['id'], counselor_id, date, time_slot)
        return jsonify({
            'message': 'Appointment booked successfully',
            'appointment': appt
        }), 201
    except Exception as e:
        return jsonify({'message': 'Failed to schedule appointment', 'error': str(e)}), 500


@appointment_bp.route('/appointments', methods=['GET'])
@token_required
def get_appointments(current_user):
    db = get_db()
    try:
        appts = db.get_appointments_by_user(current_user['id'], current_user['role'])
        return jsonify(appts), 200
    except Exception as e:
        return jsonify({'message': 'Failed to retrieve appointments', 'error': str(e)}), 500


@appointment_bp.route('/appointment/<appointment_id>', methods=['PATCH'])
@token_required
def update_appointment(current_user, appointment_id):
    # Only counselors or admins should update status
    if current_user['role'] not in ('counselor', 'admin'):
        return jsonify({'message': 'Access denied. Only counselors or admins can update status.'}), 403

    data = request.get_json() or {}
    status = data.get('status') # Approved, Completed

    if not status or status not in ('Approved', 'Completed', 'Pending'):
        return jsonify({'message': 'Invalid status. Must be Pending, Approved, or Completed'}), 400

    db = get_db()
    try:
        updated = db.update_appointment_status(appointment_id, status)
        if not updated:
            return jsonify({'message': 'Appointment not found'}), 404
        return jsonify({
            'message': f'Appointment status updated to {status}',
            'appointment': updated
        }), 200
    except Exception as e:
        return jsonify({'message': 'Failed to update appointment status', 'error': str(e)}), 500
