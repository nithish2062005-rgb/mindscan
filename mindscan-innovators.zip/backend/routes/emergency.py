from flask import Blueprint, jsonify

emergency_bp = Blueprint('emergency', __name__)

@emergency_bp.route('/emergency-support', methods=['GET'])
def get_emergency_contacts():
    # India-based emergency mental health contacts
    contacts = [
        {
            "name": "AASRA Suicide Prevention Helpline",
            "phone": "+91 22 27546669",
            "location": "National (24/7 Helpline)",
            "languages": ["English", "Hindi"],
            "website": "http://www.aasra.info"
        },
        {
            "name": "Sneha Suicide Prevention Chennai",
            "phone": "+91 44 2464 0050",
            "location": "Chennai / Tamil Nadu (24/7 Helpline)",
            "languages": ["English", "Tamil"],
            "website": "https://snehaindia.org"
        },
        {
            "name": "KIRAN Mental Health Helpline",
            "phone": "1800-599-0019",
            "location": "Govt of India Helpline (24/7)",
            "languages": ["English", "Hindi", "Tamil", "Telugu", "Kannada", "Malayalam", "Gujarati", "Marathi"],
            "description": "Government of India social justice department toll-free helpline"
        },
        {
            "name": "Vandrevala Foundation for Mental Health",
            "phone": "+91 9999 666 555",
            "location": "National (24/7)",
            "languages": ["English", "Hindi", "Gujarati", "Marathi"],
            "website": "https://www.vandrevalafoundation.com"
        }
    ]
    return jsonify({
        "country": "India",
        "emergency_contacts": contacts,
        "recommendation": "If you or someone you know is in immediate danger or facing severe distress, please dial local helpline numbers or visit the nearest campus clinic immediately."
    }), 200
