from flask import Blueprint, request, jsonify
from database import get_db
from services.security import token_required
from services.prediction_engine import StressPredictionEngine

survey_bp = Blueprint('survey', __name__)

@survey_bp.route('/survey', methods=['POST'])
@token_required
def submit_survey(current_user):
    data = request.get_json() or {}
    survey_type = data.get('survey_type') # GAD-7, PHQ-9, PSS
    answers = data.get('answers')
    score = data.get('score')

    if not survey_type or answers is None or score is None:
        return jsonify({'message': 'Missing required fields: survey_type, answers, score'}), 400

    if survey_type not in ('GAD-7', 'PHQ-9', 'PSS'):
        return jsonify({'message': 'Invalid survey_type. Must be GAD-7, PHQ-9, or PSS'}), 400

    db = get_db()
    try:
        record = db.save_survey(current_user['id'], survey_type, answers, int(score))
        return jsonify({
            'message': 'Survey submitted successfully',
            'survey': record
        }), 201
    except Exception as e:
        return jsonify({'message': 'Failed to save survey submission', 'error': str(e)}), 500


@survey_bp.route('/predict', methods=['POST'])
def predict_stress():
    data = request.get_json() or {}
    phq_score = data.get('phq_score')
    gad_score = data.get('gad_score')
    sleep_hours = data.get('sleep_hours')
    mood = data.get('mood')

    if phq_score is None or gad_score is None or sleep_hours is None or not mood:
        return jsonify({'message': 'Missing fields. Required: phq_score, gad_score, sleep_hours, mood'}), 400

    try:
        prediction = StressPredictionEngine.predict(
            int(phq_score), 
            int(gad_score), 
            float(sleep_hours), 
            str(mood)
        )
        return jsonify(prediction), 200
    except ValueError as e:
        return jsonify({'message': 'Invalid numerical value for scores or sleep_hours'}), 400
    except Exception as e:
        return jsonify({'message': 'Stress prediction calculation failed', 'error': str(e)}), 500
