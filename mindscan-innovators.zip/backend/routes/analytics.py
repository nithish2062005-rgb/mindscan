from flask import Blueprint, jsonify
from database import get_db
from services.security import token_required

analytics_bp = Blueprint('analytics', __name__)

@analytics_bp.route('/dashboard/student', methods=['GET'])
@token_required
def get_student_dashboard(current_user):
    db = get_db()
    try:
        # Fetch student survey history
        surveys = db.get_surveys_by_user(current_user['id'])
        # Fetch student mood logs
        moods = db.get_mood_history(current_user['id'])
        # Fetch student appointments
        appts = db.get_appointments_by_user(current_user['id'], 'student')

        # Mood distribution aggregation
        mood_summary = {}
        for m in moods:
            mood_summary[m['mood']] = mood_summary.get(m['mood'], 0) + 1

        # Calculate average stress score from mood history
        avg_mood_stress = 0
        if moods:
            avg_mood_stress = round(sum(m['stress_score'] for m in moods) / len(moods), 1)

        # Get latest survey details
        latest_survey = surveys[0] if surveys else None

        return jsonify({
            'student_id': current_user['id'],
            'student_name': current_user['name'],
            'email': current_user['email'],
            'metrics': {
                'total_completed_surveys': len(surveys),
                'total_mood_logs': len(moods),
                'total_scheduled_sessions': len(appts),
                'average_mood_stress': avg_mood_stress
            },
            'mood_distribution': mood_summary,
            'latest_assessment': latest_survey,
            'appointments': appts[:5] # Return latest 5 appointments
        }), 200
    except Exception as e:
        return jsonify({'message': 'Failed to load student analytics', 'error': str(e)}), 500


@analytics_bp.route('/dashboard/admin', methods=['GET'])
@token_required
def get_admin_dashboard(current_user):
    # Restrict to Admin or Counselor roles
    if current_user['role'] not in ('admin', 'counselor'):
        return jsonify({'message': 'Access Denied. Admins and Counselors only.'}), 403

    db = get_db()
    try:
        analytics = db.get_admin_analytics()
        return jsonify(analytics), 200
    except Exception as e:
        return jsonify({'message': 'Failed to compile admin dashboard analytics', 'error': str(e)}), 500
