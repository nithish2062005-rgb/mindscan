import os
from flask import Flask, jsonify
from flask_cors import CORS
from config import Config
from database import get_db

def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)

    # Enable CORS for frontend cross-origin API calls (defaulting to allow D:\mind previews)
    CORS(app, resources={r"/*": {"origins": "*"}})

    # Initialize database
    db_provider = get_db()
    
    # SQLite requires Flask App Context initialization
    if Config.DATABASE_PROVIDER == 'sqlite':
        db_provider.init_app(app)

    # Register blueprints directly on root level to match exact requested routes
    from routes.auth import auth_bp
    from routes.survey import survey_bp
    from routes.mood import mood_bp
    from routes.appointment import appointment_bp
    from routes.analytics import analytics_bp
    from routes.emergency import emergency_bp

    app.register_blueprint(auth_bp)
    app.register_blueprint(survey_bp)
    app.register_blueprint(mood_bp)
    app.register_blueprint(appointment_bp)
    app.register_blueprint(analytics_bp)
    app.register_blueprint(emergency_bp)

    @app.route('/health', methods=['GET'])
    def health_check():
        return jsonify({
            "status": "healthy",
            "database_provider": Config.DATABASE_PROVIDER,
            "version": "1.0.0"
        }), 200

    return app

if __name__ == '__main__':
    app = create_app()
    port = int(os.environ.get("PORT", 5000))
    print(f"MindScan Innovators Backend starting on port {port}...")
    app.run(host='0.0.0.0', port=port, debug=Config.DEBUG)
