import uuid
from datetime import datetime
from database.db_interface import DatabaseInterface

class MongoDBProvider(DatabaseInterface):
    def __init__(self, mongo_uri=None):
        self.db = None
        if mongo_uri:
            self.init_db(mongo_uri)

    def init_db(self, mongo_uri):
        from pymongo import MongoClient
        # Extract database name from URI, default to 'mindscan'
        client = MongoClient(mongo_uri)
        db_name = mongo_uri.split('/')[-1] if '/' in mongo_uri else 'mindscan'
        if '?' in db_name:
            db_name = db_name.split('?')[0]
        self.db = client[db_name or 'mindscan']

    def save_user(self, name, email, hashed_password, role):
        user_id = str(uuid.uuid4())
        user_data = {
            "_id": user_id,
            "name": name,
            "email": email,
            "password": hashed_password,
            "role": role
        }
        self.db.users.insert_one(user_data)
        return {
            "id": user_id,
            "name": name,
            "email": email,
            "role": role
        }

    def get_user_by_email(self, email):
        user = self.db.users.find_one({"email": email})
        if not user:
            return None
        return {
            "id": user["_id"],
            "name": user["name"],
            "email": user["email"],
            "password": user["password"],
            "role": user["role"]
        }

    def get_user_by_id(self, user_id):
        user = self.db.users.find_one({"_id": user_id})
        if not user:
            return None
        return {
            "id": user["_id"],
            "name": user["name"],
            "email": user["email"],
            "role": user["role"]
        }

    def save_survey(self, user_id, survey_type, answers, score):
        survey_id = str(uuid.uuid4())
        survey_data = {
            "_id": survey_id,
            "user_id": user_id,
            "survey_type": survey_type,
            "answers": answers,
            "score": score,
            "timestamp": datetime.utcnow()
        }
        self.db.surveys.insert_one(survey_data)
        return {
            "id": survey_id,
            "user_id": user_id,
            "survey_type": survey_type,
            "score": score,
            "timestamp": survey_data["timestamp"].isoformat()
        }

    def get_surveys_by_user(self, user_id):
        cursor = self.db.surveys.find({"user_id": user_id}).sort("timestamp", -1)
        return [
            {
                "id": doc["_id"],
                "user_id": doc["user_id"],
                "survey_type": doc["survey_type"],
                "answers": doc["answers"],
                "score": doc["score"],
                "timestamp": doc["timestamp"].isoformat()
            } for doc in cursor
        ]

    def save_mood(self, user_id, mood, stress_score, note):
        mood_id = str(uuid.uuid4())
        mood_data = {
            "_id": mood_id,
            "user_id": user_id,
            "mood": mood,
            "stress_score": stress_score,
            "note": note,
            "timestamp": datetime.utcnow()
        }
        self.db.moods.insert_one(mood_data)
        return {
            "id": mood_id,
            "user_id": user_id,
            "mood": mood,
            "stress_score": stress_score,
            "note": note,
            "timestamp": mood_data["timestamp"].isoformat()
        }

    def get_mood_history(self, user_id):
        cursor = self.db.moods.find({"user_id": user_id}).sort("timestamp", -1)
        return [
            {
                "id": doc["_id"],
                "user_id": doc["user_id"],
                "mood": doc["mood"],
                "stress_score": doc["stress_score"],
                "note": doc.get("note", ""),
                "timestamp": doc["timestamp"].isoformat()
            } for doc in cursor
        ]

    def save_appointment(self, student_id, counselor_id, date, time_slot):
        appt_id = str(uuid.uuid4())
        appt_data = {
            "_id": appt_id,
            "student_id": student_id,
            "counselor_id": counselor_id,
            "date": date,
            "time_slot": time_slot,
            "status": "Pending",
            "timestamp": datetime.utcnow()
        }
        self.db.appointments.insert_one(appt_data)
        return {
            "id": appt_id,
            "student_id": student_id,
            "counselor_id": counselor_id,
            "date": date,
            "time_slot": time_slot,
            "status": "Pending",
            "timestamp": appt_data["timestamp"].isoformat()
        }

    def get_appointments_by_user(self, user_id, role):
        if role == 'student':
            query = {"student_id": user_id}
        elif role == 'counselor':
            query = {"counselor_id": user_id}
        else:
            query = {}

        cursor = self.db.appointments.find(query).sort("timestamp", -1)
        results = []
        for doc in cursor:
            student = self.db.users.find_one({"_id": doc["student_id"]})
            counselor = self.db.users.find_one({"_id": doc["counselor_id"]})
            results.append({
                "id": doc["_id"],
                "student_id": doc["student_id"],
                "student_name": student["name"] if student else "Unknown Student",
                "counselor_id": doc["counselor_id"],
                "counselor_name": counselor["name"] if counselor else "Unknown Counselor",
                "date": doc["date"],
                "time_slot": doc["time_slot"],
                "status": doc["status"],
                "timestamp": doc["timestamp"].isoformat()
            })
        return results

    def update_appointment_status(self, appointment_id, status):
        result = self.db.appointments.update_one(
            {"_id": appointment_id},
            {"$set": {"status": status}}
        )
        if result.matched_count == 0:
            return None
        return {
            "id": appointment_id,
            "status": status
        }

    def get_admin_analytics(self):
        total_surveys = self.db.surveys.count_documents({})
        total_users = self.db.users.count_documents({})
        total_students = self.db.users.count_documents({"role": "student"})
        
        # High risk calculation
        high_risk_count = 0
        students = self.db.users.find({"role": "student"})
        for s in students:
            # Get latest survey
            latest = self.db.surveys.find_one({"user_id": s["_id"]}, sort=[("timestamp", -1)])
            if latest and latest["score"] > 14:
                high_risk_count += 1

        # Mood analytics aggregation
        pipeline = [
            {"$group": {"_id": "$mood", "count": {"$sum": 1}}}
        ]
        mood_agg = list(self.db.moods.aggregate(pipeline))
        mood_counts = {item["_id"]: item["count"] for item in mood_agg}

        # Appointments
        total_appts = self.db.appointments.count_documents({})
        pending_appts = self.db.appointments.count_documents({"status": "Pending"})
        approved_appts = self.db.appointments.count_documents({"status": "Approved"})
        completed_appts = self.db.appointments.count_documents({"status": "Completed"})

        return {
            "total_surveys": total_surveys,
            "total_users": total_users,
            "total_students": total_students,
            "high_risk_students": high_risk_count,
            "mood_analytics": mood_counts,
            "appointments": {
                "total": total_appts,
                "pending": pending_appts,
                "approved": approved_appts,
                "completed": completed_appts
            }
        }
