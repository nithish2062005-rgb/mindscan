import uuid
from datetime import datetime
from database.db_interface import DatabaseInterface

class FirebaseProvider(DatabaseInterface):
    def __init__(self, cred_path=None):
        self.db = None
        if cred_path:
            self.init_db(cred_path)

    def init_db(self, cred_path):
        import firebase_admin
        from firebase_admin import credentials, firestore
        
        # Check if already initialized to avoid exception
        if not firebase_admin._apps:
            cred = credentials.Certificate(cred_path)
            firebase_admin.initialize_app(cred)
        self.db = firestore.client()

    def save_user(self, name, email, hashed_password, role):
        user_id = str(uuid.uuid4())
        user_ref = self.db.collection('users').document(user_id)
        user_data = {
            "id": user_id,
            "name": name,
            "email": email,
            "password": hashed_password,
            "role": role
        }
        user_ref.set(user_data)
        return {
            "id": user_id,
            "name": name,
            "email": email,
            "role": role
        }

    def get_user_by_email(self, email):
        users_ref = self.db.collection('users')
        query = users_ref.where('email', '==', email).limit(1).stream()
        for doc in query:
            data = doc.to_dict()
            return {
                "id": doc.id,
                "name": data["name"],
                "email": data["email"],
                "password": data["password"],
                "role": data["role"]
            }
        return None

    def get_user_by_id(self, user_id):
        doc = self.db.collection('users').document(user_id).get()
        if not doc.exists:
            return None
        data = doc.to_dict()
        return {
            "id": doc.id,
            "name": data["name"],
            "email": data["email"],
            "role": data["role"]
        }

    def save_survey(self, user_id, survey_type, answers, score):
        survey_id = str(uuid.uuid4())
        survey_ref = self.db.collection('surveys').document(survey_id)
        survey_data = {
            "id": survey_id,
            "user_id": user_id,
            "survey_type": survey_type,
            "answers": answers,
            "score": score,
            "timestamp": datetime.utcnow()
        }
        survey_ref.set(survey_data)
        return {
            "id": survey_id,
            "user_id": user_id,
            "survey_type": survey_type,
            "score": score,
            "timestamp": survey_data["timestamp"].isoformat()
        }

    def get_surveys_by_user(self, user_id):
        surveys_ref = self.db.collection('surveys')
        query = surveys_ref.where('user_id', '==', user_id).order_by('timestamp', direction='DESCENDING').stream()
        results = []
        for doc in query:
            data = doc.to_dict()
            timestamp = data["timestamp"]
            # Convert firebase datetime/timestamp to ISO string
            if hasattr(timestamp, 'isoformat'):
                ts_str = timestamp.isoformat()
            else:
                ts_str = str(timestamp)
            results.append({
                "id": doc.id,
                "user_id": data["user_id"],
                "survey_type": data["survey_type"],
                "answers": data["answers"],
                "score": data["score"],
                "timestamp": ts_str
            })
        return results

    def save_mood(self, user_id, mood, stress_score, note):
        mood_id = str(uuid.uuid4())
        mood_ref = self.db.collection('moods').document(mood_id)
        mood_data = {
            "id": mood_id,
            "user_id": user_id,
            "mood": mood,
            "stress_score": stress_score,
            "note": note,
            "timestamp": datetime.utcnow()
        }
        mood_ref.set(mood_data)
        return {
            "id": mood_id,
            "user_id": user_id,
            "mood": mood,
            "stress_score": stress_score,
            "note": note,
            "timestamp": mood_data["timestamp"].isoformat()
        }

    def get_mood_history(self, user_id):
        moods_ref = self.db.collection('moods')
        query = moods_ref.where('user_id', '==', user_id).order_by('timestamp', direction='DESCENDING').stream()
        results = []
        for doc in query:
            data = doc.to_dict()
            timestamp = data["timestamp"]
            if hasattr(timestamp, 'isoformat'):
                ts_str = timestamp.isoformat()
            else:
                ts_str = str(timestamp)
            results.append({
                "id": doc.id,
                "user_id": data["user_id"],
                "mood": data["mood"],
                "stress_score": data["stress_score"],
                "note": data.get("note", ""),
                "timestamp": ts_str
            })
        return results

    def save_appointment(self, student_id, counselor_id, date, time_slot):
        appt_id = str(uuid.uuid4())
        appt_ref = self.db.collection('appointments').document(appt_id)
        appt_data = {
            "id": appt_id,
            "student_id": student_id,
            "counselor_id": counselor_id,
            "date": date,
            "time_slot": time_slot,
            "status": "Pending",
            "timestamp": datetime.utcnow()
        }
        appt_ref.set(appt_data)
        return {
            "id": appt_id,
            "student_id": student_id,
            "counselor_id": counselor_id,
            "date": date,
            "time_slot": time_slot,
            "status": "Pending",
            "timestamp": appt_data["timestamp"].isoformat()
        }

    def get_appointments_by_user(self, user_id, role):
        appts_ref = self.db.collection('appointments')
        if role == 'student':
            query = appts_ref.where('student_id', '==', user_id).stream()
        elif role == 'counselor':
            query = appts_ref.where('counselor_id', '==', user_id).stream()
        else:
            query = appts_ref.stream()

        results = []
        for doc in query:
            data = doc.to_dict()
            student_doc = self.db.collection('users').document(data["student_id"]).get()
            student_name = student_doc.to_dict()["name"] if student_doc.exists else "Unknown Student"
            counselor_doc = self.db.collection('users').document(data["counselor_id"]).get()
            counselor_name = counselor_doc.to_dict()["name"] if counselor_doc.exists else "Unknown Counselor"
            
            timestamp = data["timestamp"]
            if hasattr(timestamp, 'isoformat'):
                ts_str = timestamp.isoformat()
            else:
                ts_str = str(timestamp)
                
            results.append({
                "id": doc.id,
                "student_id": data["student_id"],
                "student_name": student_name,
                "counselor_id": data["counselor_id"],
                "counselor_name": counselor_name,
                "date": data["date"],
                "time_slot": data["time_slot"],
                "status": data["status"],
                "timestamp": ts_str
            })
        
        # Sort manually by timestamp desc since Firestore doesn't easily support cross-field indexes without setup
        results.sort(key=lambda x: x["timestamp"], reverse=True)
        return results

    def update_appointment_status(self, appointment_id, status):
        appt_ref = self.db.collection('appointments').document(appointment_id)
        doc = appt_ref.get()
        if not doc.exists:
            return None
        appt_ref.update({"status": status})
        return {
            "id": appointment_id,
            "status": status
        }

    def get_admin_analytics(self):
        # Firestore collections sizes can be fetched
        surveys = self.db.collection('surveys').stream()
        total_surveys = sum(1 for _ in surveys)
        
        users = self.db.collection('users').stream()
        total_users = 0
        total_students = 0
        students_list = []
        for doc in users:
            total_users += 1
            data = doc.to_dict()
            if data.get("role") == "student":
                total_students += 1
                students_list.append(data)

        # High risk calculation
        high_risk_count = 0
        for student in students_list:
            # query latest survey
            surveys_ref = self.db.collection('surveys')
            q = surveys_ref.where('user_id', '==', student["id"]).order_by('timestamp', direction='DESCENDING').limit(1).stream()
            for doc in q:
                if doc.to_dict().get("score", 0) > 14:
                    high_risk_count += 1

        # Mood analytics
        moods = self.db.collection('moods').stream()
        mood_counts = {}
        for doc in moods:
            m = doc.to_dict().get("mood")
            if m:
                mood_counts[m] = mood_counts.get(m, 0) + 1

        # Appointments
        appts = self.db.collection('appointments').stream()
        total_appts = 0
        pending_appts = 0
        approved_appts = 0
        completed_appts = 0
        for doc in appts:
            total_appts += 1
            status = doc.to_dict().get("status")
            if status == "Pending":
                pending_appts += 1
            elif status == "Approved":
                approved_appts += 1
            elif status == "Completed":
                completed_appts += 1

        return {
            "total_surveys": total_surveys,
            "total_users": total_users,
            "total_students": total_students,
            "high_risk_students": high_risk_count,
            "mood_analytics": mood_counts,
            "appointments": {
                "total": total_appts,
                "pending": pending_appts,
                "approved": approved_appts,
                "completed": completed_appts
            }
        }
