class StressPredictionEngine:
    
    @staticmethod
    def predict(phq_score, gad_score, sleep_hours, mood):
        """
        AI Stress Prediction logic.
        Combines PHQ-9 (depression screening), GAD-7 (anxiety screening), sleep hours,
        and current self-reported mood to output a comprehensive risk score and stress level.
        
        This is a rule-based expert system designed as a modular service.
        It can easily be extended/replaced with a machine learning model (e.g. Scikit-learn Random Forest) 
        without changing the API signatures.
        """
        # 1. Normalize scores (PHQ-9 max = 27, GAD-7 max = 21)
        phq_ratio = min(max(phq_score, 0), 27) / 27.0
        gad_ratio = min(max(gad_score, 0), 21) / 21.0
        
        # 2. Convert sleep hours to a stress penalty
        # Optimal: 7-9 hours. Deficit: <6 hours.
        sleep_ratio = 0.0
        if sleep_hours < 5:
            sleep_ratio = 1.0  # Maximum sleep deficit stress
        elif sleep_hours < 6:
            sleep_ratio = 0.7
        elif sleep_hours < 7:
            sleep_ratio = 0.3
        elif sleep_hours > 10:
            sleep_ratio = 0.4  # Excessive sleep (possible depression indicator)
            
        # 3. Convert mood to a ratio
        # Mood values: Happy, Neutral, Stressed, Sad, Burnout
        mood_ratio = 0.0
        mood_lower = str(mood).lower()
        if mood_lower in ('happy', 'joy', 'calm'):
            mood_ratio = 0.0
        elif mood_lower == 'neutral':
            mood_ratio = 0.2
        elif mood_lower == 'stressed':
            mood_ratio = 0.7
        elif mood_lower == 'sad':
            mood_ratio = 0.7
        elif mood_lower == 'burnout':
            mood_ratio = 1.0

        # 4. Weighted Risk Score Calculation
        # GAD: 40%, PHQ: 40%, Sleep Deficit: 10%, Self-reported Mood: 10%
        risk_score = (
            (gad_ratio * 40.0) +
            (phq_ratio * 40.0) +
            (sleep_ratio * 10.0) +
            (mood_ratio * 10.0)
        )
        
        # Keep risk score strictly between 0 and 100
        risk_score = round(min(max(risk_score, 0.0), 100.0), 1)

        # 5. Stress Level and Recommendations mapping
        if risk_score < 30.0:
            stress_level = "Low"
            recommendation = "Low stress indices detected. Continue maintaining healthy study intervals and sleep patterns."
        elif risk_score < 60.0:
            stress_level = "Moderate"
            recommendation = "Moderate stress warning. Leverage daily box breathing, log moods in the Mood Journal, and practice mindfulness."
        elif risk_score < 85.0:
            stress_level = "High"
            recommendation = "High stress levels detected. We strongly suggest scheduling a session with a campus psychologist."
        else:
            stress_level = "Critical"
            recommendation = "CRITICAL: Severe stress indicators flag high burnout risk. Immediate counselor consultation or helpline outreach is recommended."

        return {
            "stress_level": stress_level,
            "risk_score": risk_score,
            "recommendation": recommendation
        }
