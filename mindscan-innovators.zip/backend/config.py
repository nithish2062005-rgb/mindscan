import os
from dotenv import load_dotenv

# Load environment variables from .env file if it exists
load_dotenv()

class Config:
    PORT = int(os.getenv("PORT", 5000))
    DEBUG = os.getenv("DEBUG", "True").lower() in ("true", "1", "yes")
    JWT_SECRET = os.getenv("JWT_SECRET", "default_secret_key_change_me")
    PASSWORD_SALT_ROUNDS = int(os.getenv("PASSWORD_SALT_ROUNDS", 12))
    
    # DB configuration
    DATABASE_PROVIDER = os.getenv("DATABASE_PROVIDER", "sqlite").lower()
    
    # SQLite / SQL Alchemy Uri
    SQLALCHEMY_DATABASE_URI = os.getenv("SQLALCHEMY_DATABASE_URI", "sqlite:///mindscan.db")
    
    # MongoDB Config
    MONGO_URI = os.getenv("MONGO_URI", "mongodb://localhost:27017/mindscan")
    
    # Firebase Service Account Path
    FIREBASE_CREDENTIALS_PATH = os.getenv("FIREBASE_CREDENTIALS_PATH", "")
