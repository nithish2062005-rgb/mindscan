from flask import Blueprint, request, jsonify
from database import get_db
from services.security import token_required

mood_bp = Blueprint('mood', __name__)

@mood_bp.route('/mood', methods=['POST'])
@token_required
def log_mood(current_user):
    data = request.get_json() or {}
    mood = data.get('mood') # Happy, Neutral, Stressed, Sad, Burnout
    stress_score = data.get('stress_score')
    note = data.get('note', '')

    if not mood or stress_score is None:
        return jsonify({'message': 'Missing required fields: mood, stress_score'}), 400

    # Validate mood type
    valid_moods = ('Happy', 'Neutral', 'Stressed', 'Sad', 'Burnout')
    mood_title = str(mood).capitalize()
    if mood_title not in valid_moods:
        return jsonify({'message': f'Invalid mood. Must be one of: {", ".join(valid_moods)}'}), 400

    db = get_db()
    try:
        record = db.save_mood(current_user['id'], mood_title, int(stress_score), note)
        return jsonify({
            'message': 'Mood logged successfully',
            'mood_log': record
        }), 201
    except Exception as e:
        return jsonify({'message': 'Failed to save mood log', 'error': str(e)}), 500


@mood_bp.route('/mood-history', methods=['GET'])
@token_required
def get_mood_history(current_user):
    db = get_db()
    try:
        history = db.get_mood_history(current_user['id'])
        return jsonify(history), 200
    except Exception as e:
        return jsonify({'message': 'Failed to retrieve mood history', 'error': str(e)}), 500
