from config import Config

db_instance = None

def get_db():
    global db_instance
    if db_instance is not None:
        return db_instance
        
    provider = Config.DATABASE_PROVIDER
    
    if provider == 'mongodb':
        from database.mongodb_provider import MongoDBProvider
        db_instance = MongoDBProvider(Config.MONGO_URI)
        print("Database: Initialized MongoDB Provider.")
    elif provider == 'firebase':
        from database.firebase_provider import FirebaseProvider
        db_instance = FirebaseProvider(Config.FIREBASE_CREDENTIALS_PATH)
        print("Database: Initialized Firebase Provider.")
    else:
        # Default to SQLite
        from database.sqlite_provider import SQLiteProvider
        db_instance = SQLiteProvider()
        print("Database: Initialized SQLite Provider.")
        
    return db_instance
