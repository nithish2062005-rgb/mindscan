import unittest
import json
from app import create_app
from config import Config

class MindScanBackendTestCase(unittest.TestCase):
    
    def setUp(self):
        # Override config variables for unit testing
        Config.DATABASE_PROVIDER = 'sqlite'
        Config.SQLALCHEMY_DATABASE_URI = 'sqlite:///:memory:' # Clean, fast in-memory DB
        Config.DEBUG = False
        Config.JWT_SECRET = 'test_secret_key_1234'
        
        # Create Flask app and testing client
        self.app = create_app()
        self.client = self.app.test_client()
        
        # Create tables
        with self.app.app_context():
            from database.sqlite_provider import db
            db.create_all()
            
    def tearDown(self):
        # Drop all tables after test completion
        with self.app.app_context():
            from database.sqlite_provider import db
            db.session.remove()
            db.drop_all()

    def register_and_login(self, email="test@student.edu", password="secure123", role="student"):
        # Helper method to register and login a test user
        self.client.post('/signup', json={
            "name": "Test User",
            "email": email,
            "password": password,
            "role": role
        })
        response = self.client.post('/login', json={
            "email": email,
            "password": password
        })
        data = json.loads(response.data)
        return data.get('token'), data.get('user', {}).get('id')

    def test_health_check(self):
        response = self.client.get('/health')
        self.assertEqual(response.status_code, 200)
        data = json.loads(response.data)
        self.assertEqual(data['status'], 'healthy')

    def test_user_authentication(self):
        # 1. Successful Signup
        signup_resp = self.client.post('/signup', json={
            "name": "Alice Smith",
            "email": "alice@university.edu",
            "password": "alicepassword",
            "role": "student"
        })
        self.assertEqual(signup_resp.status_code, 201)
        
        # 2. Duplicate Signup should fail
        dup_resp = self.client.post('/signup', json={
            "name": "Alice Smith",
            "email": "alice@university.edu",
            "password": "alicepassword"
        })
        self.assertEqual(dup_resp.status_code, 409)

        # 3. Successful Login
        login_resp = self.client.post('/login', json={
            "email": "alice@university.edu",
            "password": "alicepassword"
        })
        self.assertEqual(login_resp.status_code, 200)
        login_data = json.loads(login_resp.data)
        self.assertIn('token', login_data)
        self.assertEqual(login_data['user']['name'], 'Alice Smith')
        
        # 4. Failed Login
        bad_login = self.client.post('/login', json={
            "email": "alice@university.edu",
            "password": "wrongpassword"
        })
        self.assertEqual(bad_login.status_code, 401)

    def test_protected_route_without_token(self):
        response = self.client.get('/mood-history')
        self.assertEqual(response.status_code, 401)
        data = json.loads(response.data)
        self.assertEqual(data['message'], 'Authorization Token is missing!')

    def test_stress_prediction_engine(self):
        # Test low stress inputs
        response = self.client.post('/predict', json={
            "phq_score": 2,
            "gad_score": 1,
            "sleep_hours": 8.0,
            "mood": "happy"
        })
        self.assertEqual(response.status_code, 200)
        data = json.loads(response.data)
        self.assertEqual(data['stress_level'], 'Low')
        self.assertTrue(data['risk_score'] < 30.0)

        # Test critical stress inputs
        response_crit = self.client.post('/predict', json={
            "phq_score": 25,
            "gad_score": 20,
            "sleep_hours": 4.0,
            "mood": "burnout"
        })
        self.assertEqual(response_crit.status_code, 200)
        data_crit = json.loads(response_crit.data)
        self.assertEqual(data_crit['stress_level'], 'Critical')
        self.assertTrue(data_crit['risk_score'] > 85.0)

    def test_survey_submission(self):
        token, _ = self.register_and_login()
        headers = {'Authorization': f'Bearer {token}'}

        response = self.client.post('/survey', json={
            "survey_type": "GAD-7",
            "answers": [2, 1, 3, 0, 1, 2, 2],
            "score": 11
        }, headers=headers)
        self.assertEqual(response.status_code, 201)
        
        data = json.loads(response.data)
        self.assertEqual(data['survey']['survey_type'], 'GAD-7')
        self.assertEqual(data['survey']['score'], 11)

    def test_mood_tracking(self):
        token, _ = self.register_and_login()
        headers = {'Authorization': f'Bearer {token}'}

        # Log mood
        log_resp = self.client.post('/mood', json={
            "mood": "stressed",
            "stress_score": 75,
            "note": "Exam season is starting."
        }, headers=headers)
        self.assertEqual(log_resp.status_code, 201)

        # Get history
        hist_resp = self.client.get('/mood-history', headers=headers)
        self.assertEqual(hist_resp.status_code, 200)
        history = json.loads(hist_resp.data)
        self.assertEqual(len(history), 1)
        self.assertEqual(history[0]['mood'], 'Stressed')
        self.assertEqual(history[0]['stress_score'], 75)

    def test_counselor_booking(self):
        # Register a counselor
        c_token, c_id = self.register_and_login(email="dr.counselor@campus.edu", role="counselor")
        
        # Register a student
        s_token, s_id = self.register_and_login(email="student@university.edu", role="student")
        
        headers = {'Authorization': f'Bearer {s_token}'}
        
        # Book appointment
        appt_resp = self.client.post('/appointment', json={
            "counselor_id": c_id,
            "date": "2026-06-30",
            "time": "Monday at 10:00 AM IST"
        }, headers=headers)
        self.assertEqual(appt_resp.status_code, 201)
        appt_data = json.loads(appt_resp.data)
        self.assertEqual(appt_data['appointment']['status'], 'Pending')
        appt_id = appt_data['appointment']['id']

        # Counselor checks active sessions
        c_headers = {'Authorization': f'Bearer {c_token}'}
        list_resp = self.client.get('/appointments', headers=c_headers)
        self.assertEqual(list_resp.status_code, 200)
        self.assertEqual(len(json.loads(list_resp.data)), 1)

        # Counselor approves appointment
        patch_resp = self.client.patch(f'/appointment/{appt_id}', json={
            "status": "Approved"
        }, headers=c_headers)
        self.assertEqual(patch_resp.status_code, 200)
        
        # Student gets updated history
        student_appts = self.client.get('/appointments', headers=headers)
        self.assertEqual(json.loads(student_appts.data)[0]['status'], 'Approved')

    def test_dashboard_analytics(self):
        # Register admin & student
        admin_token, _ = self.register_and_login(email="admin@campus.edu", role="admin")
        student_token, s_id = self.register_and_login()

        # Log some data for the student
        s_headers = {'Authorization': f'Bearer {student_token}'}
        self.client.post('/survey', json={"survey_type": "GAD-7", "answers": [1, 2, 2, 1], "score": 6}, headers=s_headers)
        self.client.post('/mood', json={"mood": "happy", "stress_score": 20}, headers=s_headers)

        # 1. Fetch student dashboard
        s_dash_resp = self.client.get('/dashboard/student', headers=s_headers)
        self.assertEqual(s_dash_resp.status_code, 200)
        s_data = json.loads(s_dash_resp.data)
        self.assertEqual(s_data['metrics']['total_completed_surveys'], 1)
        self.assertEqual(s_data['metrics']['average_mood_stress'], 20.0)

        # 2. Fetch admin dashboard
        a_headers = {'Authorization': f'Bearer {admin_token}'}
        admin_dash_resp = self.client.get('/dashboard/admin', headers=a_headers)
        self.assertEqual(admin_dash_resp.status_code, 200)
        a_data = json.loads(admin_dash_resp.data)
        self.assertEqual(a_data['total_surveys'], 1)
        self.assertEqual(a_data['total_students'], 1)

    def test_google_login(self):
        # 1. Test google login with mock token (should register user)
        response = self.client.post('/google-login', json={
            "credential": "mock_google_token_sam.jones@university.edu"
        })
        self.assertEqual(response.status_code, 200)
        data = json.loads(response.data)
        self.assertIn('token', data)
        self.assertEqual(data['user']['email'], 'sam.jones@university.edu')
        self.assertEqual(data['user']['name'], 'Sam Jones')
        self.assertEqual(data['user']['role'], 'student')

        # 2. Test google login again (should sign in existing user)
        response_exist = self.client.post('/google-login', json={
            "credential": "mock_google_token_sam.jones@university.edu"
        })
        self.assertEqual(response_exist.status_code, 200)
        data_exist = json.loads(response_exist.data)
        self.assertEqual(data_exist['user']['id'], data['user']['id'])

        # 3. Test google login with empty payload
        response_bad = self.client.post('/google-login', json={})
        self.assertEqual(response_bad.status_code, 400)

if __name__ == '__main__':
    unittest.main()
