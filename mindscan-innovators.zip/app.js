// MindScan Innovators - Advanced AI Systems
function initializeMindScanApp() {
  console.log("MindScan Innovators App Initialized!");
  // ----------------------------------------------------
  // 1. Gamification XP Engine
  // ----------------------------------------------------
  let currentXP = 450;
  let currentLevel = 2;
  const xpAlertContainer = document.getElementById('xpAlertContainer');
  const profileXP = document.getElementById('profileXP');
  const profileLevel = document.getElementById('profileLevel');

  function earnXP(amount, actionName = "Wellness Action") {
    // Create Alert Bubble
    if (xpAlertContainer) {
      const bubble = document.createElement('div');
      bubble.className = 'xp-alert-bubble';
      bubble.innerHTML = `<span>✦</span> +${amount} XP: ${actionName}`;
      xpAlertContainer.appendChild(bubble);

      // Remove after animation finishes
      setTimeout(() => {
        bubble.remove();
      }, 3500);
    }

    currentXP += amount;
    
    // Check level up (Level 2: 450xp, Level 3 needs 1000xp, etc.)
    const nextLevelXPNeeded = currentLevel * 500;
    if (currentXP >= nextLevelXPNeeded) {
      currentLevel++;
      if (profileLevel) {
        profileLevel.textContent = `Lv. ${currentLevel}`;
      }
      
      // Level up alert
      setTimeout(() => {
        if (xpAlertContainer) {
          const lvBubble = document.createElement('div');
          lvBubble.className = 'xp-alert-bubble';
          lvBubble.style.background = 'linear-gradient(135deg, var(--accent), var(--success))';
          lvBubble.innerHTML = `<span>🎉</span> LEVEL UP! Level ${currentLevel}`;
          xpAlertContainer.appendChild(lvBubble);
          setTimeout(() => lvBubble.remove(), 4000);
        }
      }, 800);
    }

    // Update Header
    if (profileXP) {
      profileXP.textContent = `${currentXP} XP`;
    }
  }


  // ----------------------------------------------------
  // 2. Multilingual Support
  // ----------------------------------------------------
  const langSelect = document.getElementById('langSelect');
  const translatables = {
    'en': {
      'nav-challenges': 'Challenges',
      'nav-about': 'About',
      'nav-features': 'Features',
      'nav-dashboard': 'Dashboard',
      'nav-labs': 'AI Labs',
      'nav-counselors': 'Counselors',
      'nav-faq': 'FAQ',
      'btn-scan': 'Take Scan',
      'hero-title': 'MindScan <span>Innovators</span>',
      'hero-desc': 'Your Mind Matters. AI That Understands, Supports, and Cares.',
      'btn-scan-long': 'Take Mental Health Scan',
      'btn-getstarted': 'Get Started'
    },
    'es': {
      'nav-challenges': 'Desafíos',
      'nav-about': 'Nosotros',
      'nav-features': 'Funciones',
      'nav-dashboard': 'Panel',
      'nav-labs': 'Lab de IA',
      'nav-counselors': 'Terapeutas',
      'nav-faq': 'FAQ',
      'btn-scan': 'Evaluación',
      'hero-title': 'Innovadores <span>MindScan</span>',
      'hero-desc': 'Soporte digital de salud mental impulsado por IA para estudiantes. Empoderando la educación superior con herramientas de evaluación inteligente y asistencia psicológica en tiempo real.',
      'btn-scan-long': 'Hacer Evaluación Mental',
      'btn-getstarted': 'Comenzar'
    },
    'fr': {
      'nav-challenges': 'Défis',
      'nav-about': 'À Propos',
      'nav-features': 'Fonctions',
      'nav-dashboard': 'Tableau',
      'nav-labs': 'Lab d\'IA',
      'nav-counselors': 'Conseillers',
      'nav-faq': 'FAQ',
      'btn-scan': 'Évaluer',
      'hero-title': 'MindScan <span>Innovateurs</span>',
      'hero-desc': 'Soutien numérique en santé mentale propulsé par l\'IA pour les étudiants. Outils de dépistage intelligents, plans de bien-être personnalisés et assistance en temps réel.',
      'btn-scan-long': 'Faire un bilan mental',
      'btn-getstarted': 'Démarrer'
    },
    'de': {
      'nav-challenges': 'Herausforderung',
      'nav-about': 'Über Uns',
      'nav-features': 'Funktionen',
      'nav-dashboard': 'Dashboard',
      'nav-labs': 'KI-Labs',
      'nav-counselors': 'Therapeuten',
      'nav-faq': 'FAQ',
      'btn-scan': 'Scan Starten',
      'hero-title': 'MindScan <span>Innovatoren</span>',
      'hero-desc': 'KI-gestützte digitale Unterstützung für studentische mentale Gesundheit. Intelligente Screening-Tools, personalisierte Wellnesspläne und psychologische Beratung.',
      'btn-scan-long': 'Mentalen Scan Starten',
      'btn-getstarted': 'Starten'
    },
    'hi': {
      'nav-challenges': 'चुनौतियां',
      'nav-about': 'हमारे बारे में',
      'nav-features': 'विशेषताएं',
      'nav-dashboard': 'डैशबोर्ड',
      'nav-labs': 'एआई लैब्स',
      'nav-counselors': 'सलाहकार',
      'nav-faq': 'प्रश्नोत्तरी',
      'btn-scan': 'जांच करें',
      'hero-title': 'माइंडस्कैन <span>इनोवेटर्स</span>',
      'hero-desc': 'छात्रों के लिए एआई-संचालित डिजिटल मानसिक स्वास्थ्य सहायता। उच्च शिक्षा में नैदानिक जांच, व्यक्तिगत कल्याण योजनाएं और त्वरित मनोवैज्ञानिक परामर्श।',
      'btn-scan-long': 'मानसिक स्वास्थ्य जांच करें',
      'btn-getstarted': 'शुरू करें'
    },
    'ta': {
      'nav-challenges': 'சவால்கள்',
      'nav-about': 'எங்களைப் பற்றி',
      'nav-features': 'அம்சங்கள்',
      'nav-dashboard': 'டாஷ்போர்டு',
      'nav-labs': 'AI ஆய்வகம்',
      'nav-counselors': 'ஆலோசகர்கள்',
      'nav-faq': 'கேள்விகள்',
      'btn-scan': 'பரிசோதனை',
      'hero-title': 'மைண்ட்ஸ்கேன் <span>இன்னோவேட்டர்ஸ்</span>',
      'hero-desc': 'மாணவர்களுக்கான AI-இயங்கும் டிஜிட்டல் மனநல ஆதரவு. நுண்ணறிவுள்ள திரையிடல் கருவிகள், தனிப்பயனாக்கப்பட்ட நல்வாழ்வுத் திட்டங்கள் மற்றும் உடனடி உளவியல் ஆலோசனை.',
      'btn-scan-long': 'மனநல பரிசோதனை செய்யவும்',
      'btn-getstarted': 'தொடங்குங்கள்'
    }
  };

  if (langSelect) {
    langSelect.addEventListener('change', (e) => {
      const lang = e.target.value;
      const dict = translatables[lang];
      if (dict) {
        document.querySelectorAll('[data-tr]').forEach(el => {
          const key = el.getAttribute('data-tr');
          if (dict[key]) {
            if (key === 'hero-title') {
              el.innerHTML = dict[key];
            } else {
              el.textContent = dict[key];
            }
          }
        });
        earnXP(15, `Language changed to ${lang.toUpperCase()}`);
      }
    });
  }


  // ----------------------------------------------------
  // 3. Emergency SOS Support Modals
  // ----------------------------------------------------
  const sosFab = document.getElementById('sosFab');
  const sosModal = document.getElementById('sosModal');
  const closeSosModal = document.getElementById('closeSosModal');
  const sosModalOverlay = document.getElementById('sosModalOverlay');
  const btnCallCampusCounselor = document.getElementById('btnCallCampusCounselor');

  if (sosFab) {
    sosFab.addEventListener('click', () => {
      sosModal.classList.add('active');
    });
  }

  function closeSos() {
    sosModal.classList.remove('active');
  }

  if (closeSosModal) {
    closeSosModal.addEventListener('click', closeSos);
    sosModalOverlay.addEventListener('click', closeSos);
  }

  if (btnCallCampusCounselor) {
    btnCallCampusCounselor.addEventListener('click', () => {
      btnCallCampusCounselor.disabled = true;
      btnCallCampusCounselor.querySelector('div').textContent = "Connecting Emergency Line...";
      
      setTimeout(() => {
        alert("📞 Secure VOIP Crisis Channel opened. Connecting to Wellness Dispatcher.");
        btnCallCampusCounselor.disabled = false;
        btnCallCampusCounselor.querySelector('div').textContent = "Contact Campus On-Duty Psychologist";
        closeSos();
      }, 1500);
    });
  }


  // ----------------------------------------------------
  // 4. AI Wellness Labs - Mood Journaling NLP Sentiment
  // ----------------------------------------------------
  const journalInput = document.getElementById('journalInput');
  const btnAnalyzeJournal = document.getElementById('btnAnalyzeJournal');
  const journalResults = document.getElementById('journalResults');
  
  const journalJoy = document.getElementById('journalJoy');
  const journalStress = document.getElementById('journalStress');
  const journalSad = document.getElementById('journalSad');
  
  const barJournalJoy = document.getElementById('barJournalJoy');
  const barJournalStress = document.getElementById('barJournalStress');
  const barJournalSad = document.getElementById('barJournalSad');

  if (btnAnalyzeJournal) {
    btnAnalyzeJournal.addEventListener('click', () => {
      const text = journalInput.value.trim();
      if (text.length < 10) {
        alert("Please write a journal entry of at least 10 characters to analyze sentiment parameters.");
        return;
      }

      btnAnalyzeJournal.disabled = true;
      btnAnalyzeJournal.querySelector('span').textContent = "Analyzing Sentiment Metrics...";

      setTimeout(() => {
        let joy = 30;
        let stress = 25;
        let sadness = 15;

        const lowerText = text.toLowerCase();
        if (lowerText.includes('stressed') || lowerText.includes('exam') || lowerText.includes('tired') || lowerText.includes('deadline')) {
          stress += 50;
          joy -= 10;
        }
        if (lowerText.includes('sad') || lowerText.includes('lonely') || lowerText.includes('down') || lowerText.includes('cry')) {
          sadness += 55;
          joy -= 15;
        }
        if (lowerText.includes('happy') || lowerText.includes('great') || lowerText.includes('good') || lowerText.includes('win') || lowerText.includes('accomplished')) {
          joy += 55;
          stress -= 15;
          sadness -= 10;
        }

        // Clamp values 0-100
        joy = Math.max(5, Math.min(100, joy));
        stress = Math.max(5, Math.min(100, stress));
        sadness = Math.max(5, Math.min(100, sadness));

        // Display results
        journalJoy.textContent = `${joy}%`;
        journalStress.textContent = `${stress}%`;
        journalSad.textContent = `${sadness}%`;

        barJournalJoy.style.width = `${joy}%`;
        barJournalStress.style.width = `${stress}%`;
        barJournalSad.style.width = `${sadness}%`;

        journalResults.style.display = 'block';
        
        btnAnalyzeJournal.disabled = false;
        btnAnalyzeJournal.querySelector('span').textContent = "Analyze Journal Sentiment (+50 XP)";
        
        earnXP(50, "Mood Journal Sentiment analyzed");
      }, 1500);
    });
  }


  // ----------------------------------------------------
  // 5. AI Wellness Labs - Voice Emotion Detection (Mic Wave)
  // ----------------------------------------------------
  const btnRecordVoice = document.getElementById('btnRecordVoice');
  const voiceTimer = document.getElementById('voiceTimer');
  const voiceStatus = document.getElementById('voiceStatus');
  const voiceResults = document.getElementById('voiceResults');
  const voiceStress = document.getElementById('voiceStress');
  const voiceTone = document.getElementById('voiceTone');
  const voiceWaveCanvas = document.getElementById('voiceWaveCanvas');

  let isRecordingVoice = false;
  let waveAnimationId;

  if (voiceWaveCanvas) {
    const waveCtx = voiceWaveCanvas.getContext('2d');
    
    function drawVoiceWave(amplitude = 0) {
      waveCtx.clearRect(0, 0, voiceWaveCanvas.width, voiceWaveCanvas.height);
      waveCtx.strokeStyle = 'rgba(6, 182, 212, 0.4)';
      waveCtx.lineWidth = 2;
      
      waveCtx.beginPath();
      const numLines = 40;
      const step = voiceWaveCanvas.width / numLines;
      const centerY = voiceWaveCanvas.height / 2;

      for (let i = 0; i < numLines; i++) {
        const x = i * step;
        const height = (Math.sin(i * 0.5 + Date.now() * 0.01) * amplitude) * (Math.random() * 0.6 + 0.4);
        waveCtx.moveTo(x, centerY - height);
        waveCtx.lineTo(x, centerY + height);
      }
      waveCtx.stroke();

      if (isRecordingVoice) {
        waveAnimationId = requestAnimationFrame(() => drawVoiceWave(amplitude));
      }
    }

    if (btnRecordVoice) {
      btnRecordVoice.addEventListener('click', () => {
        if (isRecordingVoice) return;
        
        isRecordingVoice = true;
        btnRecordVoice.classList.add('recording');
        voiceStatus.textContent = "Listening to audio feed...";
        voiceResults.style.display = 'none';

        // Animate Waveform
        drawVoiceWave(30);

        // Count down 3 seconds
        let seconds = 0;
        const timerInterval = setInterval(() => {
          seconds += 0.5;
          voiceTimer.textContent = `${seconds.toFixed(1)}s`;
          if (seconds >= 3.0) {
            clearInterval(timerInterval);
            stopVoiceRecord();
          }
        }, 500);
      });
    }

    function stopVoiceRecord() {
      isRecordingVoice = false;
      btnRecordVoice.classList.remove('recording');
      cancelAnimationFrame(waveAnimationId);
      
      // Clear waveform
      waveCtx.clearRect(0, 0, voiceWaveCanvas.width, voiceWaveCanvas.height);
      
      // Calculate random vocal metrics
      const stressPct = Math.floor(10 + Math.random() * 20);
      voiceStress.textContent = `Low (${stressPct}%)`;
      voiceStress.style.color = "var(--success)";
      voiceTone.textContent = "Calm, Controlled & Stable";
      
      voiceStatus.textContent = "Analysis Complete!";
      voiceTimer.textContent = "3.0s";
      voiceResults.style.display = 'block';

      earnXP(50, "Voice Emotion Analyzed");
    }
  }


  // ----------------------------------------------------
  // 6. Dual Dashboard Portals (Student vs. Campus Admin)
  // ----------------------------------------------------
  const btnStudentView = document.getElementById('btnStudentView');
  const btnAdminView = document.getElementById('btnAdminView');
  const studentPortalView = document.getElementById('studentPortalView');
  const adminPortalView = document.getElementById('adminPortalView');

  if (btnStudentView && btnAdminView) {
    btnStudentView.addEventListener('click', () => {
      btnStudentView.classList.add('active');
      btnAdminView.classList.remove('active');
      studentPortalView.style.display = 'grid';
      adminPortalView.style.display = 'none';
      earnXP(10, "Switched to Student Portal");
    });

    btnAdminView.addEventListener('click', () => {
      btnAdminView.classList.add('active');
      btnStudentView.classList.remove('active');
      adminPortalView.style.display = 'grid';
      studentPortalView.style.display = 'none';
      earnXP(20, "Accessing Campus Admin View");
    });
  }


  // ----------------------------------------------------
  // 7. Dynamic AI Recommendation Cards Engine
  // ----------------------------------------------------
  const recsGrid = document.getElementById('recsGrid');
  const calmRecs = [
    { title: "Optimal Focus Plan", desc: "Your indicators are great. Take a 25-minute study sprint with focus soundscapes." },
    { title: "Daily Gratitude Journal", desc: "Log 3 small academic wins today to strengthen structural neuroplasticity." }
  ];
  const stressRecs = [
    { title: "10-Min Box Breathing", desc: "URGENT: Ground stress triggers immediately. Breathe in 4s, hold 4s, exhale 4s." },
    { title: "Schedule Counseling Session", desc: "Highly recommended. A wellness therapist is ready. Safe, anonymous consultation." }
  ];

  function renderRecommendations(mode) {
    if (!recsGrid) return;
    recsGrid.innerHTML = '';
    const activeRecs = mode === 'calm' ? calmRecs : stressRecs;
    
    activeRecs.forEach(rec => {
      const card = document.createElement('div');
      card.className = 'rec-card';
      card.innerHTML = `<h5>${rec.title}</h5><p>${rec.desc}</p>`;
      recsGrid.appendChild(card);
    });
  }


  // ----------------------------------------------------
  // 8. Wearable Device Integration Pairing + ECG + Stress Spike
  // ----------------------------------------------------
  const btnConnectWearable = document.getElementById('btnConnectWearable');
  const wearableStatusDot = document.getElementById('wearableStatusDot');
  const wearableStatusText = document.getElementById('wearableStatusText');
  const wearableStats = document.getElementById('wearableStats');
  
  const wearableHR = document.getElementById('wearableHR');
  const wearableHRV = document.getElementById('wearableHRV');
  const wearableStressLabel = document.getElementById('wearableStressLabel');
  const btnSimulateStressSpike = document.getElementById('btnSimulateStressSpike');
  const btnSimulateCalm = document.getElementById('btnSimulateCalm');
  const ecgCanvas = document.getElementById('ecgCanvas');

  let wearableIsStressed = false;
  let ecgAnimId = null;
  let wearableDriftInterval = null;

  function startECG() {
    if (!ecgCanvas) return;
    const ctx = ecgCanvas.getContext('2d');
    ecgCanvas.width = ecgCanvas.offsetWidth * 2;
    ecgCanvas.height = ecgCanvas.offsetHeight * 2;
    ctx.scale(2, 2);
    const w = ecgCanvas.offsetWidth;
    const h = ecgCanvas.offsetHeight;
    let offset = 0;

    function drawECG() {
      ctx.clearRect(0, 0, w, h);
      ctx.strokeStyle = wearableIsStressed ? '#ef4444' : '#10b981';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      const mid = h / 2;
      const speed = wearableIsStressed ? 3 : 2;
      for (let x = 0; x < w; x++) {
        const phase = (x + offset) * 0.08;
        const cycle = phase % (Math.PI * 2);
        let y = mid;
        if (cycle > 2.0 && cycle < 2.4) y = mid - (wearableIsStressed ? 18 : 14);
        else if (cycle > 2.4 && cycle < 2.7) y = mid + (wearableIsStressed ? 6 : 4);
        else if (cycle > 3.0 && cycle < 3.3) y = mid - (wearableIsStressed ? 10 : 6);
        else y = mid + Math.sin(phase * 0.5) * 1;
        if (x === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.stroke();
      offset += speed;
      ecgAnimId = requestAnimationFrame(drawECG);
    }
    drawECG();
  }

  function updateWearableBiometrics() {
    if (wearableIsStressed) {
      const hrVal = Math.floor(105 + Math.random() * 15);
      const hrvVal = Math.floor(22 + Math.random() * 10);
      if (wearableHR) wearableHR.textContent = `${hrVal} bpm`;
      if (wearableHRV) wearableHRV.textContent = `${hrvVal} ms`;
      if (wearableStressLabel) {
        wearableStressLabel.textContent = `High (${Math.floor(72 + Math.random() * 15)}%)`;
        wearableStressLabel.style.color = 'var(--danger)';
      }
    } else {
      const hrVal = Math.floor(68 + Math.random() * 10);
      const hrvVal = Math.floor(60 + Math.random() * 15);
      if (wearableHR) wearableHR.textContent = `${hrVal} bpm`;
      if (wearableHRV) wearableHRV.textContent = `${hrvVal} ms`;
      if (wearableStressLabel) {
        wearableStressLabel.textContent = `Normal (${Math.floor(15 + Math.random() * 12)}%)`;
        wearableStressLabel.style.color = 'var(--success)';
      }
    }
  }

  if (btnConnectWearable) {
    btnConnectWearable.addEventListener('click', () => {
      btnConnectWearable.disabled = true;
      btnConnectWearable.querySelector('span').textContent = "Pairing via Bluetooth...";
      
      setTimeout(() => {
        wearableStatusDot.classList.add('active');
        wearableStatusText.textContent = "Connected: Apple Watch";
        wearableStats.style.display = 'grid';
        btnConnectWearable.style.display = 'none';
        wearableIsStressed = false;
        updateWearableBiometrics();
        startECG();
        earnXP(75, "Connected Apple Watch");
        
        wearableDriftInterval = setInterval(updateWearableBiometrics, 2500);
      }, 1800);
    });
  }

  if (btnSimulateStressSpike) {
    btnSimulateStressSpike.addEventListener('click', () => {
      wearableIsStressed = true;
      updateWearableBiometrics();
      btnSimulateStressSpike.style.display = 'none';
      if (btnSimulateCalm) btnSimulateCalm.style.display = 'inline-flex';
      // Also push dashboard to stress
      if (demoStressBtn) demoStressBtn.click();
      earnXP(25, "IoT Stress Spike Simulated");
    });
  }
  if (btnSimulateCalm) {
    btnSimulateCalm.addEventListener('click', () => {
      wearableIsStressed = false;
      updateWearableBiometrics();
      btnSimulateCalm.style.display = 'none';
      if (btnSimulateStressSpike) btnSimulateStressSpike.style.display = 'inline-flex';
      if (demoCalmBtn) demoCalmBtn.click();
      earnXP(25, "IoT Calm State Restored");
    });
  }


  // ----------------------------------------------------
  // 9. AI Brain Preloader Screen Sequence (Revamped)
  // ----------------------------------------------------
  const preloader = document.getElementById('preloader');
  const progressBar = document.getElementById('preloaderProgressBar');
  const statusLabel = document.getElementById('preloaderStatus');

  const preloaderLogs = [
    { progress: 15, text: "Connecting secure websocket tunnel..." },
    { progress: 35, text: "Initializing homomorphic encryption keys..." },
    { progress: 55, text: "Booting local PHQ-9 & GAD-7 NLP classifiers..." },
    { progress: 75, text: "Caching calming soundscapes & meditation nodes..." },
    { progress: 95, text: "Establishing anonymous student workspace..." },
    { progress: 100, text: "System fully secured. Welcome." }
  ];

  let preIndex = 0;
  function updatePreloader() {
    if (preIndex < preloaderLogs.length) {
      const step = preloaderLogs[preIndex];
      if (progressBar) progressBar.style.width = `${step.progress}%`;
      if (statusLabel) statusLabel.textContent = step.text;
      
      const delay = preIndex === 0 ? 300 : (preIndex === 4 ? 600 : 400);
      preIndex++;
      setTimeout(updatePreloader, delay);
    } else {
      setTimeout(() => {
        if (preloader) preloader.classList.add('fade-out');
        document.body.style.overflow = '';
      }, 300);
    }
  }

  document.body.style.overflow = 'hidden';
  setTimeout(updatePreloader, 400);


  // ----------------------------------------------------
  // 10. AI Dashboard Preview Logic (Gauge & Path updates)
  // ----------------------------------------------------
  const gaugeFill = document.getElementById('dashboardGaugeFill');
  const gaugeVal = document.getElementById('dashboardGaugeVal');
  const gaugeStatus = document.getElementById('dashboardGaugeStatus');
  const riskFill = document.getElementById('dashboardRiskFill');
  const riskPercent = document.getElementById('dashboardRiskPercent');
  const riskCategory = document.getElementById('dashboardRiskCategory');
  const sleepFill = document.getElementById('dashboardSleepFill');
  const sleepPercent = document.getElementById('dashboardSleepPercent');
  const sleepStatus = document.getElementById('dashboardSleepStatus');

  const demoCalmBtn = document.getElementById('demoCalmBtn');
  const demoStressBtn = document.getElementById('demoStressBtn');
  const moodBtns = document.querySelectorAll('.mood-btn');
  const moodFeedback = document.getElementById('moodFeedback');

  function updateDashboardUI(mode, customSundayVal = null) {
    let score, statusText, riskScore, riskCatText, sleepScore, sleepText, statusClass;
    let dataSet = [];

    if (mode === 'calm') {
      score = 28;
      statusText = "Optimal State";
      statusClass = "status-optimal";
      riskScore = 18;
      riskCatText = "Low Risk";
      sleepScore = 78;
      sleepText = "Restful (7.8h)";
      dataSet = [...calmMoodData];
      renderRecommendations('calm');
    } else {
      score = 82;
      statusText = "Critical Stress";
      statusClass = "status-critical";
      riskScore = 88;
      riskCatText = "Severe Risk Alert";
      sleepScore = 42;
      sleepText = "Deficit (4.2h)";
      dataSet = [...stressMoodData];
      renderRecommendations('stress');
    }

    if (customSundayVal !== null) {
      dataSet[6] = customSundayVal;
      const diff = 70 - customSundayVal;
      score = Math.max(10, Math.min(95, Math.floor(score + diff * 0.4)));
      if (score < 40) {
        statusText = "Optimal State";
        statusClass = "status-optimal";
        riskScore = score - 5;
        riskCatText = "Low Risk";
        sleepScore = 75;
        sleepText = "Restful (7.5h)";
        renderRecommendations('calm');
      } else if (score < 70) {
        statusText = "Moderate Stress";
        statusClass = "status-moderate";
        riskScore = score + 5;
        riskCatText = "Moderate Risk";
        sleepScore = 60;
        sleepText = "Tired (6.0h)";
        renderRecommendations('stress');
      } else {
        statusText = "Critical Stress";
        statusClass = "status-critical";
        riskScore = score + 8;
        riskCatText = "Severe Risk Alert";
        sleepScore = 40;
        sleepText = "Deficit (4.0h)";
        renderRecommendations('stress');
      }
    }

    // Gauge Update
    const maxOffset = 220;
    const offset = maxOffset - (maxOffset * score / 100);
    if (gaugeFill) {
      gaugeFill.style.strokeDashoffset = offset;
      gaugeVal.textContent = score;
      gaugeStatus.textContent = statusText;
      gaugeStatus.className = `gauge-status ${statusClass}`;
    }

    // Risk Meter Update
    if (riskFill) {
      riskFill.style.width = `${riskScore}%`;
      riskFill.style.background = riskScore > 70 ? 'var(--danger)' : (riskScore > 40 ? 'var(--warning)' : 'linear-gradient(90deg, var(--success), var(--warning))');
      riskPercent.textContent = `${riskScore}%`;
      riskPercent.style.color = riskScore > 70 ? 'var(--danger)' : (riskScore > 40 ? 'var(--warning)' : 'var(--success)');
      riskCategory.textContent = riskCatText;
      riskCategory.style.color = riskScore > 70 ? 'var(--danger)' : (riskScore > 40 ? 'var(--warning)' : 'var(--success)');
    }

    // Sleep Meter Update
    if (sleepFill) {
      sleepFill.style.width = `${sleepScore}%`;
      sleepFill.style.background = sleepScore < 50 ? 'var(--danger)' : (sleepScore < 70 ? 'var(--warning)' : 'linear-gradient(90deg, var(--accent), var(--secondary))');
      sleepPercent.textContent = `${sleepScore}%`;
      sleepPercent.style.color = sleepScore < 50 ? 'var(--danger)' : (sleepScore < 70 ? 'var(--warning)' : 'var(--accent)');
      sleepStatus.textContent = sleepText;
      sleepStatus.style.color = sleepScore < 50 ? 'var(--danger)' : (sleepScore < 70 ? 'var(--warning)' : 'var(--accent)');
    }

    // Path Update
    const yCoords = mapDataToGraphY(dataSet);
    const linePath = document.getElementById('graphLinePath');
    const areaPath = document.getElementById('graphAreaPath');
    const pointsGroup = document.getElementById('graphPoints');

    if (linePath && areaPath) {
      const dLine = `M 40,${yCoords[0]} L 105,${yCoords[1]} L 170,${yCoords[2]} L 235,${yCoords[3]} L 300,${yCoords[4]} L 365,${yCoords[5]} L 430,${yCoords[6]}`;
      const dArea = `${dLine} L 430,130 L 40,130 Z`;

      linePath.setAttribute('d', dLine);
      areaPath.setAttribute('d', dArea);

      const circles = pointsGroup.querySelectorAll('circle');
      circles.forEach((circle, idx) => {
        circle.setAttribute('cy', yCoords[idx]);
      });
    }
  }

  // Bind controls
  if (demoCalmBtn && demoStressBtn) {
    demoCalmBtn.addEventListener('click', () => {
      demoCalmBtn.classList.add('active');
      demoStressBtn.classList.remove('active');
      moodBtns.forEach(btn => btn.classList.remove('active'));
      document.querySelector('.mood-btn[data-mood="calm"]')?.classList.add('active');
      updateDashboardUI('calm');
      if (moodFeedback) moodFeedback.textContent = "Demo switched to Optimal state simulation.";
      earnXP(10, "Toggled Optimal state demo");
    });

    demoStressBtn.addEventListener('click', () => {
      demoStressBtn.classList.add('active');
      demoCalmBtn.classList.remove('active');
      moodBtns.forEach(btn => btn.classList.remove('active'));
      document.querySelector('.mood-btn[data-mood="depressed"]')?.classList.add('active');
      updateDashboardUI('stress');
      if (moodFeedback) moodFeedback.textContent = "Demo switched to Critical state simulation.";
      earnXP(10, "Toggled Critical state demo");
    });
  }

  moodBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      moodBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      
      const mood = btn.getAttribute('data-mood');
      let sundayVal = 55;
      let label = "Neutral";

      switch (mood) {
        case 'depressed': sundayVal = 15; label = "Struggling"; break;
        case 'anxious': sundayVal = 30; label = "Anxious"; break;
        case 'neutral': sundayVal = 55; label = "Neutral"; break;
        case 'calm': sundayVal = 80; label = "Calm"; break;
        case 'happy': sundayVal = 95; label = "Energetic"; break;
      }

      if (moodFeedback) moodFeedback.textContent = `Current state logged: ${label}. Graph adjusted.`;
      const isCalmActive = demoCalmBtn ? demoCalmBtn.classList.contains('active') : false;
      updateDashboardUI(isCalmActive ? 'calm' : 'stress', sundayVal);
      earnXP(20, `Daily mood logged: ${label}`);
    });
  });


  // ----------------------------------------------------
  // 11. Interactive Counselor Booking Section
  // ----------------------------------------------------
  const counselorCards = document.querySelectorAll('.counselor-card');
  const dayChips = document.getElementById('dayChips');
  const timeChips = document.getElementById('timeChips');
  const summaryCounselor = document.getElementById('summaryCounselor');
  const summaryTime = document.getElementById('summaryTime');
  const btnBookSession = document.getElementById('btnBookSession');

  const bookingModal = document.getElementById('bookingModal');
  const closeBookingModal = document.getElementById('closeBookingModal');
  const bookingModalOverlay = document.getElementById('bookingModalOverlay');
  const ticketId = document.getElementById('ticketId');
  const ticketCounselor = document.getElementById('ticketCounselor');
  const ticketTime = document.getElementById('ticketTime');
  const ticketHash = document.getElementById('ticketHash');
  const btnConfirmBookingClose = document.getElementById('btnConfirmBookingClose');

  let selectedCounselor = "Campus Psychologist";
  let selectedDay = "Monday";
  let selectedTime = "09:00 AM IST";

  counselorCards.forEach(card => {
    card.addEventListener('click', () => {
      counselorCards.forEach(c => c.classList.remove('active'));
      card.classList.add('active');
      selectedCounselor = card.querySelector('h4').textContent;
      summaryCounselor.textContent = selectedCounselor;
    });
  });

  if (dayChips) {
    dayChips.querySelectorAll('.chip').forEach(chip => {
      chip.addEventListener('click', () => {
        dayChips.querySelectorAll('.chip').forEach(c => c.classList.remove('active'));
        chip.classList.add('active');
        selectedDay = chip.getAttribute('data-val');
        updateSummaryTime();
      });
    });
  }

  if (timeChips) {
    timeChips.querySelectorAll('.chip').forEach(chip => {
      chip.addEventListener('click', () => {
        timeChips.querySelectorAll('.chip').forEach(c => c.classList.remove('active'));
        chip.classList.add('active');
        selectedTime = chip.getAttribute('data-val');
        updateSummaryTime();
      });
    });
  }

  function updateSummaryTime() {
    summaryTime.textContent = `${selectedDay} at ${selectedTime}`;
  }

  if (btnBookSession) {
    btnBookSession.addEventListener('click', () => {
      const bookingEmail = document.getElementById('bookingEmail');
      if (!bookingEmail || !bookingEmail.value.trim()) {
        alert("Please enter a valid email address to receive your confirmation ticket.");
        return;
      }
      
      const emailVal = bookingEmail.value.trim();
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(emailVal)) {
        alert("Please enter a correctly formatted email address.");
        return;
      }

      // Generate parameters
      const randId = Math.floor(10000 + Math.random() * 90000);
      const ticketIdText = `TX-${randId}-SEC`;
      
      const randHash = Array.from({length: 12}, () => Math.floor(Math.random()*16).toString(16)).join('');
      const ticketHashText = `sha256-4c${randHash}...`;
      const timeSlotText = `${selectedDay} at ${selectedTime}`;

      // Disable button & change text
      btnBookSession.disabled = true;
      const btnSpan = btnBookSession.querySelector('span');
      const originalText = btnSpan ? btnSpan.textContent : "Schedule Session Anonymously (+100 XP)";
      if (btnSpan) btnSpan.textContent = "Transmitting Booking Ticket...";

      fetch("https://formsubmit.co/ajax/nithish2062005@gmail.com", {
        method: "POST",
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        body: JSON.stringify({
          "email": emailVal,
          "_cc": emailVal,
          "Subject": "Your MindScan Counseling Session Confirmation Ticket",
          "Booking Ticket ID": ticketIdText,
          "Selected Psychologist": selectedCounselor,
          "Scheduled Time Slot": timeSlotText,
          "Decrypted Access Code": ticketHashText,
          "_subject": "Your MindScan Counseling Session Confirmation Ticket"
        })
      })
      .then(response => {
        if (response.ok) {
          // Update Modal UI
          ticketCounselor.textContent = selectedCounselor;
          ticketTime.textContent = timeSlotText;
          ticketId.textContent = ticketIdText;
          ticketHash.textContent = ticketHashText;

          // Open Modal
          bookingModal.classList.add('active');
          earnXP(100, "Scheduled counseling session");
          
          // Reset button
          btnBookSession.disabled = false;
          if (btnSpan) btnSpan.textContent = originalText;
          
          // Clear email input
          bookingEmail.value = '';
        } else {
          throw new Error("FormSubmit server error");
        }
      })
      .catch(err => {
        btnBookSession.disabled = false;
        if (btnSpan) btnSpan.textContent = originalText;
        alert("Failed to securely book session. Please check your network connection and try again.");
      });
    });
  }

  function closeBooking() {
    bookingModal.classList.remove('active');
  }
  if (closeBookingModal) {
    closeBookingModal.addEventListener('click', closeBooking);
    bookingModalOverlay.addEventListener('click', closeBooking);
    btnConfirmBookingClose.addEventListener('click', () => {
      navigator.clipboard.writeText(ticketHash.textContent).catch(() => {});
      closeBooking();
    });
  }


  // ----------------------------------------------------
  // 12. FAQ Accordion Dropdown
  // ----------------------------------------------------
  const faqItems = document.querySelectorAll('.faq-item');
  faqItems.forEach(item => {
    const btn = item.querySelector('.faq-question-btn');
    const answer = item.querySelector('.faq-answer');

    btn.addEventListener('click', () => {
      const isActive = item.classList.contains('active');
      
      faqItems.forEach(otherItem => {
        otherItem.classList.remove('active');
        otherItem.querySelector('.faq-answer').style.maxHeight = 0;
      });

      if (!isActive) {
        item.classList.add('active');
        answer.style.maxHeight = answer.scrollHeight + 'px';
      }
    });
  });


  // ----------------------------------------------------
  // 13. Contact Form validation & submission
  // ----------------------------------------------------
  const contactForm = document.getElementById('contactForm');
  if (contactForm) {
    contactForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const submitBtn = contactForm.querySelector('button[type="submit"]');
      const submitText = submitBtn.querySelector('span');

      submitBtn.style.opacity = '0.7';
      submitText.textContent = "Transmitting Secured Message...";
      submitBtn.disabled = true;

      const contactEmailVal = document.getElementById('contactEmail').value.trim();

      const formData = new FormData(contactForm);
      formData.append('_subject', 'MindScan Contact Inquiry Received');
      formData.append('_cc', contactEmailVal);

      fetch("https://formsubmit.co/ajax/nithish2062005@gmail.com", {
        method: "POST",
        body: formData,
        headers: {
          'Accept': 'application/json'
        }
      })
      .then(response => {
        if (response.ok) {
          submitBtn.style.background = 'var(--success)';
          submitBtn.style.boxShadow = '0 0 15px rgba(16, 185, 129, 0.4)';
          submitText.textContent = "Secure Message Sent Successfully ✓";
          contactForm.reset();
          earnXP(40, "Sent developer contact query");
        } else {
          submitBtn.style.background = 'var(--danger)';
          submitText.textContent = "Error sending message. Check inbox to activate FormSubmit.";
        }
      })
      .catch(() => {
        submitBtn.style.background = 'var(--danger)';
        submitText.textContent = "Oops! Network error occurred.";
      })
      .finally(() => {
        setTimeout(() => {
          submitBtn.style.background = '';
          submitBtn.style.boxShadow = '';
          submitText.textContent = "Send Message";
          submitBtn.style.opacity = '1';
          submitBtn.disabled = false;
        }, 5000);
      });
    });
  }


  // ----------------------------------------------------
  // 14. Floating AI Chatbot Widget ("Mindy") Logic + Gemini AI
  // ----------------------------------------------------
  const chatbotContainer = document.getElementById('chatbotContainer');
  const chatbotFab = document.getElementById('chatbotFab');
  const chatbotWindow = document.getElementById('chatbotWindow');
  const chatbotCloseBtn = document.getElementById('chatbotCloseBtn');
  const chatbotMessages = document.getElementById('chatbotMessages');
  const chatbotInput = document.getElementById('chatbotInput');
  const chatbotSendBtn = document.getElementById('chatbotSendBtn');
  const chatbotBadge = chatbotFab.querySelector('.chatbot-badge-dot');
  const chatbotSettingsBtn = document.getElementById('chatbotSettingsBtn');
  const chatbotSettingsPanel = document.getElementById('chatbotSettingsPanel');
  const btnSaveApiKey = document.getElementById('btnSaveApiKey');
  const geminiApiKeyInput = document.getElementById('geminiApiKey');
  const chatEngineSelect = document.getElementById('chatEngineSelect');
  const settingsPanelStatus = document.getElementById('settingsPanelStatus');

  // Load saved key
  const savedGeminiKey = localStorage.getItem('mindscan-gemini-key') || '';
  if (geminiApiKeyInput && savedGeminiKey) {
    geminiApiKeyInput.value = savedGeminiKey;
    if (chatEngineSelect) chatEngineSelect.value = 'gemini';
  }

  if (chatbotSettingsBtn && chatbotSettingsPanel) {
    chatbotSettingsBtn.addEventListener('click', () => {
      const isVisible = chatbotSettingsPanel.style.display === 'flex';
      chatbotSettingsPanel.style.display = isVisible ? 'none' : 'flex';
    });
  }

  if (btnSaveApiKey) {
    btnSaveApiKey.addEventListener('click', () => {
      const key = geminiApiKeyInput ? geminiApiKeyInput.value.trim() : '';
      if (key) {
        localStorage.setItem('mindscan-gemini-key', key);
        if (settingsPanelStatus) {
          settingsPanelStatus.style.display = 'block';
          settingsPanelStatus.textContent = 'Key saved securely in LocalStorage ✓';
          settingsPanelStatus.style.color = 'var(--success)';
        }
        if (chatEngineSelect) chatEngineSelect.value = 'gemini';
      } else {
        if (settingsPanelStatus) {
          settingsPanelStatus.style.display = 'block';
          settingsPanelStatus.textContent = 'Please enter a valid API key.';
          settingsPanelStatus.style.color = 'var(--danger)';
        }
      }
    });
  }

  function getActiveEngine() {
    return chatEngineSelect ? chatEngineSelect.value : 'local';
  }

  async function callGeminiAPI(userText) {
    const apiKey = localStorage.getItem('mindscan-gemini-key') || '';
    if (!apiKey) return null;
    const systemPrompt = `You are Mindy, a compassionate and empathetic AI mental health wellness companion for college students on the MindScan Innovators platform. You provide anonymous, supportive dialogue. You are NOT a licensed therapist. For serious crises, recommend calling AASRA (+91 22 27546669) or Sneha Chennai (+91 44 2464 0050). Keep responses concise (2-4 sentences), warm, and actionable. Never ask for personal identifying information.`;
    try {
      const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${apiKey}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          system_instruction: { parts: [{ text: systemPrompt }] },
          contents: [{ parts: [{ text: userText }] }]
        })
      });
      if (!response.ok) return null;
      const data = await response.json();
      return data?.candidates?.[0]?.content?.parts?.[0]?.text || null;
    } catch(e) {
      console.error('Gemini API error:', e);
      return null;
    }
  }

  chatbotFab.addEventListener('click', () => {
    chatbotWindow.classList.add('active');
    chatbotBadge.style.display = 'none';
    chatbotInput.focus();
  });

  chatbotCloseBtn.addEventListener('click', () => {
    chatbotWindow.classList.remove('active');
  });

  async function sendUserChatMessage() {
    const text = chatbotInput.value.trim();
    if (!text) return;

    appendMessage(text, 'user');
    chatbotInput.value = '';
    showBotTyping();

    if (getActiveEngine() === 'gemini') {
      const geminiReply = await callGeminiAPI(text);
      removeBotTyping();
      if (geminiReply) {
        appendMessage(geminiReply, 'bot');
      } else {
        appendMessage(getMindyResponse(text) + '\n\n(Gemini API unavailable — using local AI core)', 'bot');
      }
    } else {
      setTimeout(() => {
        removeBotTyping();
        const reply = getMindyResponse(text);
        appendMessage(reply, 'bot');
      }, 1200);
    }
    earnXP(15, "Conversations with Mindy AI");
  }

  chatbotSendBtn.addEventListener('click', sendUserChatMessage);
  chatbotInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') sendUserChatMessage();
  });

  function appendMessage(text, sender) {
    const bubble = document.createElement('div');
    bubble.className = `chat-message ${sender}`;
    bubble.textContent = text;
    chatbotMessages.appendChild(bubble);
    chatbotMessages.scrollTop = chatbotMessages.scrollHeight;
  }

  function showBotTyping() {
    const typingBubble = document.createElement('div');
    typingBubble.className = 'chat-message bot typing';
    typingBubble.id = 'mindyTyping';
    typingBubble.innerHTML = 'Mindy is typing<span></span><span></span><span></span>';
    chatbotMessages.appendChild(typingBubble);
    chatbotMessages.scrollTop = chatbotMessages.scrollHeight;
  }

  function removeBotTyping() {
    const bubble = document.getElementById('mindyTyping');
    if (bubble) bubble.remove();
  }

  function getMindyResponse(userText) {
    const text = userText.toLowerCase();
    const hasTakenScan = Object.keys(userAnswers).length > 0;
    
    // Check if user requests GAD-7 scan results specifically
    if (text.includes('scan') || text.includes('result') || text.includes('report') || text.includes('score') || text.includes('test results')) {
      if (hasTakenScan) {
        let riskLabel = "Low Risk (Optimal)";
        if (calculatedScanCategory === 'stress') {
          riskLabel = calculatedScanScore > 70 ? "High Clinical Stress" : "Moderate Stress Warning";
        }
        return `According to your latest GAD-7 screening report, your stress index is at ${calculatedScanScore}% (${riskLabel}). \n\nI have loaded customized recommendations for you on the main dashboard. Feel free to ask me for any specific relief advice, or check out the Counselor Booking section to schedule a secure, private conversation.`;
      } else {
        return "You haven't completed a Mental Health Scan yet! Please click the 'Take Scan' button in the navigation bar to complete the 4 quick GAD-7 questions. Once you finish, I can automatically personalize my wellness advice based on your scores.";
      }
    }

    if (text.includes('stressed') || text.includes('stress') || text.includes('burnout') || text.includes('tired')) {
      if (hasTakenScan && userAnswers[4] >= 2) {
        return `Since your latest GAD-7 scan shows that academic pressure has had a moderate-to-severe impact on your sleep patterns (score: ${userAnswers[4]}/3), you are at a higher risk of burnout. Try a 5-minute boxed breathing pause before sleeping: breathe in 4s, hold 4s, exhale 4s, hold 4s. Reviewing our dashboard Sleep Hygiene Protocol can also help. How else can I support you?`;
      }
      return "I hear you. Academic burnouts are very real. Try to take a 5-minute boxed breath pause: Breathe in for 4s, hold for 4s, exhale for 4s, hold for 4s. Would you like to review some stress reduction resources or schedule an anonymous counselor consult?";
    }
    
    if (text.includes('relax') || text.includes('rest') || text.includes('calm') || text.includes('anxious') || text.includes('anxiety') || text.includes('panic')) {
      if (hasTakenScan && userAnswers[2] >= 2) {
        return `In your recent screening, you reported having trouble relaxing or sitting still 'more than half' or 'nearly every' day (score: ${userAnswers[2]}/3). To ease this physical tension, let's try the 5-4-3-2-1 grounding method right now. Look around and name: 5 things you see, 4 things you can touch, 3 things you hear, 2 things you smell, and 1 thing you taste. Let me know when you're ready.`;
      }
      return "Anxiety can feel completely overwhelming. Try to focus on your physical surroundings: list 5 things you see, 4 things you can touch, 3 things you hear, 2 things you smell, and 1 thing you taste. This is the 5-4-3-2-1 grounding method.";
    }

    if (text.includes('sad') || text.includes('depressed') || text.includes('lonely') || text.includes('hopeless')) {
      if (hasTakenScan && userAnswers[3] >= 2) {
        return `I notice from your scan responses that you are feeling down, depressed, or hopeless regularly (score: ${userAnswers[3]}/3). Please remember that you don't have to navigate this alone. I strongly advise using our Counselor Booking panel above to schedule a private, encrypted chat with a university psychologist (no metadata logged). I'm here for you in the meantime.`;
      }
      return "I'm really sorry you're feeling this way. You don't have to carry this alone. I am here for you anonymously, but connecting with a campus specialist can make a major difference. Use our Counselor Booking panel above to schedule a private, secure talk.";
    }
    
    if (text.includes('exam') || text.includes('test') || text.includes('grade') || text.includes('study') || text.includes('academic')) {
      return "Exams can create extreme pressure. Remember, your academic performance does not define your self-worth. Break your studying into 25-minute Pomodoro focus blocks with 5-minute stretch breaks. Take it one step at a time.";
    }
    
    if (text.includes('counselor') || text.includes('appointment') || text.includes('session') || text.includes('book')) {
      return "You can book a secure, private virtual consultation directly above in our 'Online Counselor Sessions' panel! You'll get an anonymous ticket hash to log in without exposing metadata.";
    }
    
    if (text.includes('hello') || text.includes('hi') || text.includes('hey')) {
      if (hasTakenScan) {
        return `Hello again! Based on your recent GAD-7 scan (Score: ${calculatedScanScore}%), how is your anxiety and energy levels feeling right now? I'm here to listen.`;
      }
      return "Hello! I'm here. How is your energy and mood today? Tell me what is going on, I am listening.";
    }
    
    return "Thank you for sharing that with me. I'm here to listen. Tell me more about what is going on, or check out our Quick Mental Health Scan to analyze stress indexes dynamically.";
  }


  // ----------------------------------------------------
  // 15. Mental Health Scan Modal Flow Logic
  // ----------------------------------------------------
  const openScanBtns = document.querySelectorAll('.open-scan-btn');
  const scanModal = document.getElementById('scanModal');
  const closeScanModal = document.getElementById('closeScanModal');
  const modalOverlay = document.getElementById('modalOverlay');

  const scanSteps = document.querySelectorAll('.scan-step');
  const scanProgressBar = document.getElementById('scanProgressBar');
  
  const btnPrevStep = document.getElementById('btnPrevStep');
  const btnNextStep = document.getElementById('btnNextStep');
  
  const scanHeader = document.getElementById('scanHeader');
  const scanQuestionContainer = document.getElementById('scanQuestionContainer');
  const scanLoader = document.getElementById('scanLoader');
  const scanResults = document.getElementById('scanResults');

  const btnUpdateDashboard = document.getElementById('btnUpdateDashboard');
  const btnRestartScan = document.getElementById('btnRestartScan');

  let currentStep = 1;
  const totalSteps = 4;
  const userAnswers = {};

  openScanBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      scanModal.classList.add('active');
      resetScanState();
    });
  });

  function closeModal() {
    scanModal.classList.remove('active');
  }
  closeScanModal.addEventListener('click', closeModal);
  modalOverlay.addEventListener('click', closeModal);

  function resetScanState() {
    currentStep = 1;
    for (let key in userAnswers) delete userAnswers[key];
    
    scanHeader.style.display = 'block';
    scanQuestionContainer.style.display = 'block';
    scanLoader.style.display = 'none';
    scanResults.style.display = 'none';
    
    btnPrevStep.style.display = 'inline-flex';
    btnNextStep.style.display = 'inline-flex';
    btnNextStep.querySelector('span').textContent = "Next Step";

    document.querySelectorAll('.scan-option-btn').forEach(btn => btn.classList.remove('selected'));
    
    // Reset Secure Email Report form
    const scanEmail = document.getElementById('scanEmail');
    const emailReportStatus = document.getElementById('emailReportStatus');
    const btnEmailReport = document.getElementById('btnEmailReport');
    if (scanEmail) {
      scanEmail.value = '';
      scanEmail.disabled = false;
    }
    if (emailReportStatus) {
      emailReportStatus.style.display = 'none';
      emailReportStatus.textContent = '';
      emailReportStatus.style.color = '';
    }
    if (btnEmailReport) {
      btnEmailReport.disabled = false;
      const btnSpan = btnEmailReport.querySelector('span');
      if (btnSpan) btnSpan.textContent = "Email Report";
      btnEmailReport.style.background = '';
      btnEmailReport.style.boxShadow = '';
    }

    showStep(currentStep);
  }

  function showStep(stepNum) {
    scanSteps.forEach(step => {
      step.classList.remove('active');
      if (parseInt(step.getAttribute('data-step'), 10) === stepNum) {
        step.classList.add('active');
      }
    });

    const progressPercent = (stepNum / totalSteps) * 100;
    scanProgressBar.style.width = `${progressPercent}%`;

    btnPrevStep.disabled = stepNum === 1;
    const optionSelected = userAnswers[stepNum] !== undefined;
    btnNextStep.disabled = !optionSelected;

    if (stepNum === totalSteps) {
      btnNextStep.querySelector('span').textContent = "Analyze Results";
    } else {
      btnNextStep.querySelector('span').textContent = "Next Step";
    }
  }

  scanSteps.forEach(step => {
    const stepNum = parseInt(step.getAttribute('data-step'), 10);
    const options = step.querySelectorAll('.scan-option-btn');

    options.forEach(opt => {
      opt.addEventListener('click', () => {
        options.forEach(o => o.classList.remove('selected'));
        opt.classList.add('selected');
        
        userAnswers[stepNum] = parseInt(opt.getAttribute('data-value'), 10);
        btnNextStep.disabled = false;
      });
    });
  });

  btnNextStep.addEventListener('click', () => {
    if (currentStep < totalSteps) {
      currentStep++;
      showStep(currentStep);
    } else {
      runDiagnosticAnalysis();
    }
  });

  btnPrevStep.addEventListener('click', () => {
    if (currentStep > 1) {
      currentStep--;
      showStep(currentStep);
    }
  });

  function runDiagnosticAnalysis() {
    scanHeader.style.display = 'none';
    scanQuestionContainer.style.display = 'none';
    btnPrevStep.style.display = 'none';
    btnNextStep.style.display = 'none';
    
    scanLoader.style.display = 'flex';

    const logs = [
      "Securing connection...",
      "Analyzing semantic features...",
      "Calculating anxiety & GAD indices...",
      "Generating diagnostic report..."
    ];

    let preLoaderLogIdx = 0;
    const loaderText = scanLoader.querySelector('p');

    const textInterval = setInterval(() => {
      if (preLoaderLogIdx < logs.length) {
        loaderText.textContent = logs[preLoaderLogIdx];
        preLoaderLogIdx++;
      }
    }, 600);

    setTimeout(() => {
      clearInterval(textInterval);
      showDiagnosticReport();
    }, 2500);
  }

  let calculatedScanScore = 28;
  let calculatedScanCategory = 'calm';

  function showDiagnosticReport() {
    scanLoader.style.display = 'none';
    scanResults.style.display = 'block';

    let totalScore = 0;
    for (let step in userAnswers) {
      totalScore += userAnswers[step];
    }

    const maxPossible = 12;
    const percent = Math.round((totalScore / maxPossible) * 100);
    calculatedScanScore = percent;

    const badge = document.getElementById('resultBadge');
    const scoreVal = document.getElementById('resultScore');
    const textReport = document.getElementById('resultText');

    badge.className = 'result-badge';
    scoreVal.textContent = `${percent}%`;

    if (totalScore <= 3) {
      badge.classList.add('result-level-low');
      badge.textContent = "Optimal Wellness State";
      textReport.textContent = "Your screening indices point to a healthy, balanced state. Excellent. Practice periodic meditation, maintain sleep, and log moods to track fluctuations.";
      calculatedScanCategory = 'calm';
    } else if (totalScore <= 7) {
      badge.classList.add('result-level-mod');
      badge.textContent = "Moderate Stress Warning";
      textReport.textContent = "AI algorithms identify an elevated GAD level and rising stress indices. We have generated a custom wellness track. Ensure you leverage meditation tools, adjust workloads, and check progress weekly.";
      calculatedScanCategory = 'stress';
    } else {
      badge.classList.add('result-level-high');
      badge.textContent = "High Clinical Stress Detected";
      textReport.textContent = "WARNING: Critical stress indexes detected. High risk of burnout. We strongly recommend scheduling an encrypted consulting talk with campus counseling services. Use the chatbot for instant relief exercises.";
      calculatedScanCategory = 'stress';
    }

    earnXP(100, "Completed GAD-7 Mental Health Scan");
  }

  btnRestartScan.addEventListener('click', resetScanState);

  const btnEmailReport = document.getElementById('btnEmailReport');
  if (btnEmailReport) {
    btnEmailReport.addEventListener('click', () => {
      const scanEmail = document.getElementById('scanEmail');
      const emailReportStatus = document.getElementById('emailReportStatus');
      const resultBadge = document.getElementById('resultBadge');
      const resultScore = document.getElementById('resultScore');
      const resultText = document.getElementById('resultText');

      if (!scanEmail || !scanEmail.value.trim()) {
        alert("Please enter a valid email address.");
        return;
      }
      
      const emailVal = scanEmail.value.trim();
      // Basic email regex
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(emailVal)) {
        alert("Please enter a correctly formatted email address.");
        return;
      }

      const scoreText = resultScore ? resultScore.textContent : (calculatedScanScore + "%");
      const categoryText = resultBadge ? resultBadge.textContent : calculatedScanCategory;
      const reportBody = resultText ? resultText.textContent : "Diagnostic report generated.";

      btnEmailReport.disabled = true;
      const btnSpan = btnEmailReport.querySelector('span');
      if (btnSpan) btnSpan.textContent = "Sending...";
      
      if (emailReportStatus) {
        emailReportStatus.style.display = 'block';
        emailReportStatus.style.color = 'var(--text-secondary)';
        emailReportStatus.textContent = "Transmitting report to FormSubmit...";
      }

      fetch("https://formsubmit.co/ajax/nithish2062005@gmail.com", {
        method: "POST",
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        body: JSON.stringify({
          "email": emailVal,
          "_cc": emailVal,
          "Subject": "Your MindScan GAD-7 Diagnostic Report",
          "Anxiety Screening Score": scoreText,
          "Diagnostic Classification": categoryText,
          "Clinical Assessment Summary": reportBody,
          "_subject": "Your MindScan GAD-7 Diagnostic Report"
        })
      })
      .then(response => {
        if (response.ok) {
          btnEmailReport.style.background = 'var(--success)';
          btnEmailReport.style.boxShadow = '0 0 15px rgba(16, 185, 129, 0.4)';
          if (btnSpan) btnSpan.textContent = "Sent ✓";
          scanEmail.disabled = true;
          
          if (emailReportStatus) {
            emailReportStatus.style.color = 'var(--success)';
            emailReportStatus.innerHTML = "Secure Diagnostic Report sent successfully to <strong>" + emailVal + "</strong>! ✓<br><small style='color: var(--text-muted);'>Note: If this is your first time using FormSubmit with this address, check your spam/inbox to click the verification email.</small>";
          }
          earnXP(30, "Emailed diagnostic report to self");
        } else {
          throw new Error("FormSubmit server error");
        }
      })
      .catch(err => {
        btnEmailReport.disabled = false;
        if (btnSpan) btnSpan.textContent = "Email Report";
        if (emailReportStatus) {
          emailReportStatus.style.color = 'var(--danger)';
          emailReportStatus.textContent = "Failed to send report. Please try again or check connection.";
        }
      });
    });
  }

  btnUpdateDashboard.addEventListener('click', () => {
    if (calculatedScanCategory === 'calm') {
      if (demoCalmBtn) demoCalmBtn.classList.add('active');
      if (demoStressBtn) demoStressBtn.classList.remove('active');
      const sunMoodVal = Math.round(95 - (calculatedScanScore * 0.8));
      updateDashboardUI('calm', sunMoodVal);
      if (moodFeedback) moodFeedback.textContent = `Dashboard updated using Mental Health Scan: Score ${calculatedScanScore}%`;
    } else {
      if (demoStressBtn) demoStressBtn.classList.add('active');
      if (demoCalmBtn) demoCalmBtn.classList.remove('active');
      const sunMoodVal = Math.round(95 - (calculatedScanScore * 0.8));
      updateDashboardUI('stress', sunMoodVal);
      if (moodFeedback) moodFeedback.textContent = `Dashboard updated using Mental Health Scan: Score ${calculatedScanScore}%`;
    }

    closeModal();
    const dbSection = document.getElementById('dashboard');
    if (dbSection) {
      dbSection.scrollIntoView({ behavior: 'smooth' });
    }
  });

  // ----------------------------------------------------
  // 15.4a. PDF Report Download (jsPDF)
  // ----------------------------------------------------
  const btnDownloadPDF = document.getElementById('btnDownloadPDF');
  if (btnDownloadPDF) {
    btnDownloadPDF.addEventListener('click', () => {
      try {
        const { jsPDF } = window.jspdf;
        const doc = new jsPDF();
        const scoreText = document.getElementById('resultScore')?.textContent || (calculatedScanScore + '%');
        const categoryText = document.getElementById('resultBadge')?.textContent || 'N/A';
        const reportBody = document.getElementById('resultText')?.textContent || '';
        const tokenId = 'RPT-' + Math.floor(10000 + Math.random() * 90000);
        const dateStr = new Date().toLocaleString();

        // Header bar
        doc.setFillColor(29, 78, 216);
        doc.rect(0, 0, 210, 30, 'F');
        doc.setTextColor(255, 255, 255);
        doc.setFontSize(18);
        doc.setFont('helvetica', 'bold');
        doc.text('MindScan Innovators', 14, 15);
        doc.setFontSize(9);
        doc.setFont('helvetica', 'normal');
        doc.text('AI-Powered Student Mental Health Diagnostic Report', 14, 22);
        doc.text('CONFIDENTIAL // ANONYMOUS', 150, 15);
        doc.text(tokenId, 150, 22);

        // Body
        doc.setTextColor(15, 23, 42);
        doc.setFontSize(12);
        doc.setFont('helvetica', 'bold');
        doc.text('GAD-7 Diagnostic Report', 14, 42);

        doc.setFontSize(10);
        doc.setFont('helvetica', 'normal');
        doc.text(`Report Generated: ${dateStr}`, 14, 50);
        doc.text(`Security Token: ${tokenId}`, 14, 56);

        doc.setDrawColor(200);
        doc.line(14, 62, 196, 62);

        doc.setFontSize(14);
        doc.setFont('helvetica', 'bold');
        doc.text(`Anxiety Screening Score: ${scoreText}`, 14, 72);
        doc.setFontSize(11);
        doc.text(`Classification: ${categoryText}`, 14, 80);

        doc.setFontSize(10);
        doc.setFont('helvetica', 'normal');
        const splitText = doc.splitTextToSize(reportBody, 175);
        doc.text(splitText, 14, 92);

        doc.line(14, 115, 196, 115);
        doc.setFontSize(9);
        doc.setFont('helvetica', 'bold');
        doc.text('Recommended Wellness Actions:', 14, 124);
        doc.setFont('helvetica', 'normal');
        doc.text('1. Practice 10-minute daily box breathing exercises', 14, 132);
        doc.text('2. Maintain consistent sleep schedule (7-8 hours)', 14, 138);
        doc.text('3. Schedule anonymous counseling if score > 50%', 14, 144);
        doc.text('4. Use the MindScan Mood Journal weekly for tracking', 14, 150);

        // Footer
        doc.setFontSize(8);
        doc.setTextColor(120);
        doc.text('This report was generated anonymously by MindScan Innovators AI Platform.', 14, 280);
        doc.text('No personal identifying information has been stored or transmitted.', 14, 285);

        doc.save(`MindScan_Report_${tokenId}.pdf`);
        earnXP(50, 'Downloaded PDF diagnostic report');
      } catch(e) {
        alert('PDF library is still loading. Please wait a moment and try again.');
        console.error('jsPDF error:', e);
      }
    });
  }

  // ----------------------------------------------------
  // 15.4b. Admin Campus Health Report PDF
  // ----------------------------------------------------
  const btnAdminExportPDF = document.getElementById('btnAdminExportPDF');
  if (btnAdminExportPDF) {
    btnAdminExportPDF.addEventListener('click', () => {
      try {
        const { jsPDF } = window.jspdf;
        const doc = new jsPDF();
        const dateStr = new Date().toLocaleString();

        doc.setFillColor(124, 58, 237);
        doc.rect(0, 0, 210, 28, 'F');
        doc.setTextColor(255, 255, 255);
        doc.setFontSize(16);
        doc.setFont('helvetica', 'bold');
        doc.text('MindScan Campus Health Report', 14, 14);
        doc.setFontSize(9);
        doc.setFont('helvetica', 'normal');
        doc.text(`Generated: ${dateStr} | ADMIN CONFIDENTIAL`, 14, 22);

        doc.setTextColor(15, 23, 42);
        doc.setFontSize(12);
        doc.setFont('helvetica', 'bold');
        doc.text('Campus Statistics Overview', 14, 40);
        doc.setFontSize(10);
        doc.setFont('helvetica', 'normal');
        doc.text('Total Enrolled Profiles: 4,250', 14, 50);
        doc.text('Average Campus Stress Index: 38%', 14, 56);
        doc.text('Active High-Risk Alerts: 12', 14, 62);

        doc.line(14, 68, 196, 68);
        doc.setFont('helvetica', 'bold');
        doc.text('Stress by Department:', 14, 76);
        doc.setFont('helvetica', 'normal');
        doc.text('Engineering & CS: 68%', 20, 84);
        doc.text('Natural Sciences: 48%', 20, 90);
        doc.text('Business & Law: 42%', 20, 96);
        doc.text('Humanities & Arts: 24%', 20, 102);

        doc.setFontSize(8);
        doc.setTextColor(120);
        doc.text('All data anonymized. No student PII included. For authorized admin use only.', 14, 280);

        doc.save('MindScan_Campus_Health_Report.pdf');
        earnXP(40, 'Downloaded campus health report');
      } catch(e) {
        alert('PDF library is still loading. Please wait a moment and try again.');
      }
    });
  }

  // ----------------------------------------------------
  // 15.4d. Cognitive Mood Journaling PDF Export
  // ----------------------------------------------------
  const btnDownloadJournalPDF = document.getElementById('btnDownloadJournalPDF');
  if (btnDownloadJournalPDF) {
    btnDownloadJournalPDF.addEventListener('click', () => {
      try {
        const { jsPDF } = window.jspdf;
        const doc = new jsPDF();
        const dateStr = new Date().toLocaleString();
        const journalVal = document.getElementById('journalInput')?.value || '(Empty journal entry)';
        const joyVal = document.getElementById('journalJoy')?.textContent || '0%';
        const stressVal = document.getElementById('journalStress')?.textContent || '0%';
        const sadVal = document.getElementById('journalSad')?.textContent || '0%';
        const reportToken = 'JNL-' + Math.floor(10000 + Math.random() * 90000);

        doc.setFillColor(14, 165, 233);
        doc.rect(0, 0, 210, 28, 'F');
        doc.setTextColor(255, 255, 255);
        doc.setFontSize(16);
        doc.setFont('helvetica', 'bold');
        doc.text('MindScan Wellness Labs', 14, 14);
        doc.setFontSize(9);
        doc.setFont('helvetica', 'normal');
        doc.text(`Cognitive Mood Journaling Sentiment Report | ${reportToken}`, 14, 22);

        doc.setTextColor(15, 23, 42);
        doc.setFontSize(12);
        doc.setFont('helvetica', 'bold');
        doc.text('Journal Sentiment Profile', 14, 40);

        doc.setFontSize(10);
        doc.setFont('helvetica', 'normal');
        doc.text(`Generated: ${dateStr}`, 14, 48);

        doc.setFont('helvetica', 'bold');
        doc.text('Emotional Indices:', 14, 58);
        doc.setFont('helvetica', 'normal');
        doc.text(`- Joy / Calm: ${joyVal}`, 20, 66);
        doc.text(`- Academic Stress: ${stressVal}`, 20, 72);
        doc.text(`- Depressive Sentiment: ${sadVal}`, 20, 78);

        doc.line(14, 84, 196, 84);

        doc.setFont('helvetica', 'bold');
        doc.text('Journal Passage Analyzed:', 14, 94);
        doc.setFont('helvetica', 'normal');
        const splitPassage = doc.splitTextToSize(journalVal, 175);
        doc.text(splitPassage, 14, 102);

        doc.line(14, 150, 196, 150);
        doc.setFont('helvetica', 'bold');
        doc.text('AI Cognitive Support Suggestions:', 14, 158);
        doc.setFont('helvetica', 'normal');
        doc.text('1. Notice stress patterns and schedule pauses during high academic periods.', 14, 166);
        doc.text('2. Practice listing three daily accomplishments to reinforce positive cognitive framing.', 14, 172);

        doc.setFontSize(8);
        doc.setTextColor(120);
        doc.text('Anonymously processed locally. No personal data logged or transmitted.', 14, 280);

        doc.save(`MindScan_Journal_Sentiment_${reportToken}.pdf`);
        earnXP(40, 'Downloaded journal sentiment report PDF');
      } catch(e) {
        alert('PDF library is still loading. Please wait a moment and try again.');
      }
    });
  }

  // ----------------------------------------------------
  // 15.4e. Voice Emotion Analyzer PDF Export
  // ----------------------------------------------------
  const btnDownloadVoicePDF = document.getElementById('btnDownloadVoicePDF');
  if (btnDownloadVoicePDF) {
    btnDownloadVoicePDF.addEventListener('click', () => {
      try {
        const { jsPDF } = window.jspdf;
        const doc = new jsPDF();
        const dateStr = new Date().toLocaleString();
        const stressVal = document.getElementById('voiceStress')?.textContent || 'N/A';
        const toneVal = document.getElementById('voiceTone')?.textContent || 'N/A';
        const reportToken = 'VOC-' + Math.floor(10000 + Math.random() * 90000);

        doc.setFillColor(14, 165, 233);
        doc.rect(0, 0, 210, 28, 'F');
        doc.setTextColor(255, 255, 255);
        doc.setFontSize(16);
        doc.setFont('helvetica', 'bold');
        doc.text('MindScan Wellness Labs', 14, 14);
        doc.setFontSize(9);
        doc.setFont('helvetica', 'normal');
        doc.text(`Voice Emotion Diagnostic Report | ${reportToken}`, 14, 22);

        doc.setTextColor(15, 23, 42);
        doc.setFontSize(12);
        doc.setFont('helvetica', 'bold');
        doc.text('Vocal Diagnostics Overview', 14, 40);

        doc.setFontSize(10);
        doc.setFont('helvetica', 'normal');
        doc.text(`Generated: ${dateStr}`, 14, 48);
        doc.text(`Vocal Stress Indicators: ${stressVal}`, 14, 56);
        doc.text(`Acoustic Tone Analysis: ${toneVal}`, 14, 62);

        doc.line(14, 70, 196, 70);

        doc.setFont('helvetica', 'bold');
        doc.text('Acoustic Metric Profile:', 14, 80);
        doc.setFont('helvetica', 'normal');
        doc.text('- Vocal Tremor Index: Detected minimal micro-variations', 20, 88);
        doc.text('- Speech Rate: Stable and controlled (normal breathing correlation)', 20, 94);
        doc.text('- Pitch Variance: Optimal acoustic range for low anxiety states', 20, 100);

        doc.line(14, 110, 196, 110);
        doc.setFont('helvetica', 'bold');
        doc.text('Empathetic Voice Coach Recommendations:', 14, 120);
        doc.setFont('helvetica', 'normal');
        doc.text('1. Practice deep diaphragmatic breathing to stabilize vocal resonance.', 14, 128);
        doc.text('2. If vocal strain is detected, try vocal rest intervals during long lectures.', 14, 134);

        doc.setFontSize(8);
        doc.setTextColor(120);
        doc.text('Anonymously processed locally. No personal voice recordings are saved.', 14, 280);

        doc.save(`MindScan_Voice_Report_${reportToken}.pdf`);
        earnXP(40, 'Downloaded voice diagnostics report PDF');
      } catch(e) {
        alert('PDF library is still loading. Please wait a moment and try again.');
      }
    });
  }

  // ----------------------------------------------------
  // 15.4f. Session Appointment Receipt PDF Export
  // ----------------------------------------------------
  const btnDownloadBookingPDF = document.getElementById('btnDownloadBookingPDF');
  if (btnDownloadBookingPDF) {
    btnDownloadBookingPDF.addEventListener('click', () => {
      try {
        const { jsPDF } = window.jspdf;
        const doc = new jsPDF();
        const dateStr = new Date().toLocaleString();
        const counselorName = document.getElementById('ticketCounselor')?.textContent || 'Counselor';
        const timeSlot = document.getElementById('ticketTime')?.textContent || 'N/A';
        const accessHash = document.getElementById('ticketHash')?.textContent || 'N/A';
        const ticketNum = document.getElementById('ticketId')?.textContent || 'TX-00000-SEC';

        doc.setFillColor(16, 185, 129);
        doc.rect(0, 0, 210, 28, 'F');
        doc.setTextColor(255, 255, 255);
        doc.setFontSize(16);
        doc.setFont('helvetica', 'bold');
        doc.text('MindScan Counselor Bookings', 14, 14);
        doc.setFontSize(9);
        doc.setFont('helvetica', 'normal');
        doc.text(`Anonymized Access Ticket | ${ticketNum}`, 14, 22);

        doc.setTextColor(15, 23, 42);
        doc.setFontSize(12);
        doc.setFont('helvetica', 'bold');
        doc.text('Appointment Access Ticket', 14, 40);

        doc.setFontSize(10);
        doc.setFont('helvetica', 'normal');
        doc.text(`Date Booked: ${dateStr}`, 14, 48);

        doc.setFillColor(248, 250, 252);
        doc.rect(14, 56, 182, 45, 'F');
        doc.setDrawColor(226, 232, 240);
        doc.rect(14, 56, 182, 45, 'D');

        doc.setFont('helvetica', 'bold');
        doc.text('Counseling Specialist:', 20, 66);
        doc.setFont('helvetica', 'normal');
        doc.text(counselorName, 70, 66);

        doc.setFont('helvetica', 'bold');
        doc.text('Scheduled Time Slot:', 20, 74);
        doc.setFont('helvetica', 'normal');
        doc.text(timeSlot, 70, 74);

        doc.setFont('helvetica', 'bold');
        doc.text('Secure Room Access Code:', 20, 82);
        doc.setFont('helvetica', 'normal');
        doc.setFont('courier', 'bold');
        doc.text(accessHash, 70, 82);
        doc.setFont('helvetica', 'normal');

        doc.setFontSize(9);
        doc.text('* Keep this access code secure. You will enter it to unlock the private, encrypted chat room.', 14, 110);
        doc.text('  No student identity or name was tied to this booking. Completely confidential.', 14, 116);

        doc.setFontSize(8);
        doc.setTextColor(120);
        doc.text('Anonymously generated by MindScan. Student wellness is our priority.', 14, 280);

        doc.save(`MindScan_Booking_${ticketNum}.pdf`);
        earnXP(30, 'Downloaded appointment receipt PDF');
      } catch(e) {
        alert('PDF library is still loading. Please wait a moment and try again.');
      }
    });
  }

  // ----------------------------------------------------
  // 15.4g. Admin Telemetry Live Log Simulation
  // ----------------------------------------------------
  const adminTelemetryLog = document.getElementById('adminTelemetryLog');
  const telemetryEvents = [
    '[Sensor] Student #A7C2 — Heart rate 82 bpm (normal)',
    '[Alert] Student #F9B1 — Stress spike detected (89%)',
    '[System] Box Breathing module accessed by 3 students',
    '[Sensor] Student #D4E8 — Sleep deficit flagged (3.2h)',
    '[Alert] Student #B3A0 — GAD-7 score 78% — counselor routing initiated',
    '[System] Mood Journal entry logged — sentiment: moderate stress',
    '[Sensor] Student #E6F2 — HRV 28ms — high physiological stress',
    '[System] Anonymous counseling session booked (Slot: 2PM IST)',
    '[Alert] Department CS — aggregate stress index rising (+4%)',
    '[Sensor] Student #C1D9 — Heart rate 74 bpm (optimal)',
    '[System] Voice Emotion Analyzer activated — result: calm',
    '[Alert] Student #A2B7 — PHQ-9 moderate depression flag',
    '[System] 5 new profiles enrolled this session',
    '[Sensor] Student #G5H3 — Wearable sync — HR 91 bpm (elevated)',
  ];
  let telemetryIdx = 0;
  if (adminTelemetryLog) {
    setInterval(() => {
      if (adminPortalView && adminPortalView.style.display !== 'none') {
        const entry = document.createElement('div');
        const time = new Date().toLocaleTimeString();
        const evt = telemetryEvents[telemetryIdx % telemetryEvents.length];
        const isAlert = evt.startsWith('[Alert]');
        entry.style.color = isAlert ? 'var(--danger)' : 'var(--text-secondary)';
        entry.textContent = `${time} ${evt}`;
        adminTelemetryLog.appendChild(entry);
        adminTelemetryLog.scrollTop = adminTelemetryLog.scrollHeight;
        telemetryIdx++;
      }
    }, 4000);
  }

  // ----------------------------------------------------
  // 15.5. Our Impact Section Count-Up Animations
  // ----------------------------------------------------
  const benefitVals = document.querySelectorAll('.benefit-val');
  if (benefitVals.length > 0) {
    const countUp = (el) => {
      const target = parseInt(el.getAttribute('data-target'), 10);
      const suffix = el.getAttribute('data-suffix') || '';
      let current = 0;
      const duration = 1500; // 1.5 seconds duration
      const stepTime = 20; // 20ms steps for high 60fps refresh feeling
      const totalSteps = duration / stepTime;
      const increment = target / totalSteps;
      
      const timer = setInterval(() => {
        current += increment;
        if (current >= target) {
          el.textContent = target + suffix;
          clearInterval(timer);
        } else {
          el.textContent = Math.floor(current) + suffix;
        }
      }, stepTime);
    };

    const observerOptions = {
      threshold: 0.2
    };

    const observer = new IntersectionObserver((entries, obs) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          countUp(entry.target);
          obs.unobserve(entry.target);
        }
      });
    }, observerOptions);

    benefitVals.forEach(val => observer.observe(val));
  }

  // ----------------------------------------------------
  // 15.6. Light Mode / Dark Mode Theme Engine
  // ----------------------------------------------------
  const themeToggle = document.getElementById('themeToggle');
  if (themeToggle) {
    const sunIcon = themeToggle.querySelector('.sun-icon');
    const moonIcon = themeToggle.querySelector('.moon-icon');
    
    // Check initial preference
    const savedTheme = localStorage.getItem('mindscan-theme') || 'dark';
    if (savedTheme === 'light') {
      document.body.classList.add('light-mode');
      if (sunIcon) sunIcon.style.display = 'none';
      if (moonIcon) moonIcon.style.display = 'block';
    } else {
      document.body.classList.remove('light-mode');
      if (sunIcon) sunIcon.style.display = 'block';
      if (moonIcon) moonIcon.style.display = 'none';
    }
    
    themeToggle.addEventListener('click', () => {
      const isLight = document.body.classList.contains('light-mode');
      if (isLight) {
        // Switch to Dark Mode
        document.body.classList.remove('light-mode');
        localStorage.setItem('mindscan-theme', 'dark');
        if (sunIcon) sunIcon.style.display = 'block';
        if (moonIcon) moonIcon.style.display = 'none';
        earnXP(10, "Switched to Dark Theme 🌙");
      } else {
        // Switch to Light Mode
        document.body.classList.add('light-mode');
        localStorage.setItem('mindscan-theme', 'light');
        if (sunIcon) sunIcon.style.display = 'none';
        if (moonIcon) moonIcon.style.display = 'block';
        earnXP(10, "Switched to Light Theme ☀️");
      }
    });
  }

  // ----------------------------------------------------
  // 16. Local Helper Constants
  // ----------------------------------------------------
  const calmMoodData = [65, 55, 45, 60, 80, 75, 70];
  const stressMoodData = [35, 25, 30, 20, 40, 30, 25];

  function mapDataToGraphY(dataArray) {
    return dataArray.map(val => 130 - (val * 100 / 100));
  }

  // ----------------------------------------------------
  // 17. 120-Node Animated Glowing AI Brain Canvas
  // ----------------------------------------------------
  const canvas = document.getElementById('brainCanvas');
  if (canvas) {
    const ctx = canvas.getContext('2d');
    let width = canvas.width = canvas.offsetWidth;
    let height = canvas.height = canvas.offsetHeight;

    window.addEventListener('resize', () => {
      if (canvas.offsetWidth && canvas.offsetHeight) {
        width = canvas.width = canvas.offsetWidth;
        height = canvas.height = canvas.offsetHeight;
      }
    });

    const nodes = [];
    const numNodes = 120;

    // Helper to generate brain-shaped distribution
    for (let i = 0; i < numNodes; i++) {
      let x, y;
      const t = Math.random() * Math.PI * 2;
      const r = Math.random();
      
      if (r < 0.45) {
        // Left Hemisphere Cortex
        const angle = Math.PI * 0.5 + Math.random() * Math.PI;
        const radX = 50 + Math.random() * 35;
        const radY = 70 + Math.random() * 35;
        x = -30 + Math.cos(angle) * radX;
        y = -15 + Math.sin(angle) * radY;
      } else if (r < 0.9) {
        // Right Hemisphere Cortex
        const angle = -Math.PI * 0.5 + Math.random() * Math.PI;
        const radX = 50 + Math.random() * 35;
        const radY = 70 + Math.random() * 35;
        x = 30 + Math.cos(angle) * radX;
        y = -15 + Math.sin(angle) * radY;
      } else if (r < 0.95) {
        // Cerebellum (Lower back brain)
        const radX = 35 + Math.random() * 25;
        const radY = 15 + Math.random() * 15;
        x = Math.cos(t) * radX;
        y = 50 + Math.sin(t) * radY;
      } else {
        // Brainstem (Lower middle)
        x = -8 + Math.random() * 16;
        y = 60 + Math.random() * 60;
      }

      nodes.push({
        anchorX: x,
        anchorY: y,
        x: x,
        y: y,
        size: Math.random() * 2 + 1,
        angle: Math.random() * Math.PI * 2,
        speed: 0.01 + Math.random() * 0.015,
        range: 3 + Math.random() * 5,
        pulseSpeed: 0.03 + Math.random() * 0.04,
        pulseVal: Math.random()
      });
    }

    // Signals (electric impulses)
    const signals = [];
    const maxSignals = 6;

    function spawnSignal() {
      if (signals.length >= maxSignals) return;
      const startNodeIdx = Math.floor(Math.random() * nodes.length);
      signals.push({
        nodeIdx: startNodeIdx,
        history: [startNodeIdx],
        progress: 0,
        speed: 0.06
      });
    }

    function draw() {
      if (canvas.offsetWidth === 0 || canvas.offsetHeight === 0) {
        requestAnimationFrame(draw);
        return;
      }
      
      ctx.clearRect(0, 0, width, height);
      
      const centerX = width / 2;
      const centerY = height / 2;

      // Update positions
      nodes.forEach(node => {
        node.angle += node.speed;
        node.pulseVal += node.pulseSpeed;
        node.x = centerX + node.anchorX + Math.cos(node.angle) * node.range;
        node.y = centerY + node.anchorY + Math.sin(node.angle) * node.range;
      });

      // Draw connections
      ctx.lineWidth = 0.8;
      for (let i = 0; i < nodes.length; i++) {
        for (let j = i + 1; j < nodes.length; j++) {
          const dx = nodes[i].x - nodes[j].x;
          const dy = nodes[i].y - nodes[j].y;
          const dist = Math.sqrt(dx * dx + dy * dy);
          
          if (dist < 55) {
            ctx.strokeStyle = `rgba(6, 182, 212, ${0.12 - dist/450})`;
            ctx.beginPath();
            ctx.moveTo(nodes[i].x, nodes[i].y);
            ctx.lineTo(nodes[j].x, nodes[j].y);
            ctx.stroke();
          }
        }
      }

      // Update and draw signals
      if (Math.random() < 0.04) spawnSignal();
      
      for (let i = signals.length - 1; i >= 0; i--) {
        const sig = signals[i];
        sig.progress += sig.speed;
        
        const currNode = nodes[sig.nodeIdx];
        
        if (sig.progress >= 1) {
          sig.progress = 0;
          
          // Find neighbors
          const neighbors = [];
          for (let j = 0; j < nodes.length; j++) {
            if (j === sig.nodeIdx || sig.history.includes(j)) continue;
            const dx = currNode.x - nodes[j].x;
            const dy = currNode.y - nodes[j].y;
            const dist = Math.sqrt(dx * dx + dy * dy);
            if (dist < 55) neighbors.push(j);
          }

          if (neighbors.length > 0) {
            const nextNodeIdx = neighbors[Math.floor(Math.random() * neighbors.length)];
            sig.nodeIdx = nextNodeIdx;
            sig.history.push(nextNodeIdx);
            if (sig.history.length > 4) sig.history.shift();
          } else {
            signals.splice(i, 1);
            continue;
          }
        }

        // Draw signal impulse
        const prevNodeIdx = sig.history[sig.history.length - 2];
        if (prevNodeIdx !== undefined) {
          const prevNode = nodes[prevNodeIdx];
          const x = prevNode.x + (currNode.x - prevNode.x) * sig.progress;
          const y = prevNode.y + (currNode.y - prevNode.y) * sig.progress;

          ctx.fillStyle = '#7c3aed';
          ctx.beginPath();
          ctx.arc(x, y, 2.5, 0, Math.PI * 2);
          ctx.fill();
        }
      }

      // Draw nodes
      nodes.forEach(node => {
        const pulse = 0.5 + Math.sin(node.pulseVal) * 0.5;
        const alpha = 0.25 + pulse * 0.5;
        
        // Node core
        ctx.fillStyle = `rgba(6, 182, 212, ${alpha})`;
        ctx.beginPath();
        ctx.arc(node.x, node.y, node.size, 0, Math.PI * 2);
        ctx.fill();

        // Node glow aura
        if (node.size > 2.2 && pulse > 0.75) {
          ctx.fillStyle = 'rgba(124, 58, 237, 0.12)';
          ctx.beginPath();
          ctx.arc(node.x, node.y, node.size * 2.5, 0, Math.PI * 2);
          ctx.fill();
        }
      });

      requestAnimationFrame(draw);
    }

    draw();
  }

  // ----------------------------------------------------
  // 18. Floating Background Particles
  // ----------------------------------------------------
  const pCanvas = document.getElementById('particleCanvas');
  if (pCanvas) {
    const pCtx = pCanvas.getContext('2d');
    let pWidth = pCanvas.width = window.innerWidth;
    let pHeight = pCanvas.height = window.innerHeight;

    window.addEventListener('resize', () => {
      pWidth = pCanvas.width = window.innerWidth;
      pHeight = pCanvas.height = window.innerHeight;
    });

    const particles = [];
    const numParticles = 60;

    for (let i = 0; i < numParticles; i++) {
      particles.push({
        x: Math.random() * pWidth,
        y: Math.random() * pHeight,
        size: Math.random() * 1.5 + 0.5,
        speedX: (Math.random() - 0.5) * 0.15,
        speedY: (Math.random() - 0.5) * 0.15,
        alpha: Math.random(),
        pulseSpeed: 0.005 + Math.random() * 0.01
      });
    }

    function animateParticles() {
      pCtx.clearRect(0, 0, pWidth, pHeight);
      
      particles.forEach(p => {
        p.x += p.speedX;
        p.y += p.speedY;
        p.alpha += p.pulseSpeed;

        // Wrap around screen edges
        if (p.x < 0) p.x = pWidth;
        if (p.x > pWidth) p.x = 0;
        if (p.y < 0) p.y = pHeight;
        if (p.y > pHeight) p.y = 0;

        const currentAlpha = 0.1 + Math.abs(Math.sin(p.alpha)) * 0.45;
  const isLightMode = document.body.classList.contains('light-mode');
        pCtx.fillStyle = isLightMode ? `rgba(15, 23, 42, ${currentAlpha * 0.4})` : `rgba(255, 255, 255, ${currentAlpha})`;
        pCtx.beginPath();
        pCtx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        pCtx.fill();
      });

      requestAnimationFrame(animateParticles);
    }

    animateParticles();
  }

  // Automated test helper for GAD-7 scan & PDF download
  if (window.location.search.includes('test-pdf')) {
    console.log("TEST-PDF: Test query parameter detected. Starting automated test...");
    setTimeout(() => {
      const openBtns = document.querySelectorAll('.open-scan-btn');
      if (openBtns.length > 0) {
        console.log("TEST-PDF: Opening scan modal");
        openBtns[0].click();
        
        let step = 1;
        const interval = setInterval(() => {
          const activeStepOptions = document.querySelectorAll('#scanQuestionContainer .scan-step.active .scan-option-btn');
          if (activeStepOptions.length > 0) {
            console.log(`TEST-PDF: Selecting option for step ${step}`);
            activeStepOptions[0].click();
            const nextBtn = document.getElementById('btnNextStep');
            if (nextBtn) {
              console.log(`TEST-PDF: Clicking Next Step for step ${step}`);
              nextBtn.click();
              step++;
            }
          }
          if (step > 4) {
            clearInterval(interval);
            console.log("TEST-PDF: Completed GAD-7 steps. Waiting for results...");
            setTimeout(() => {
              const downloadBtn = document.getElementById('btnDownloadPDF');
              if (downloadBtn) {
                console.log("TEST-PDF: Clicking Download PDF button");
                downloadBtn.click();
              } else {
                console.error("TEST-PDF: Download PDF button not found!");
              }
            }, 3000);
          }
        }, 1000);
      } else {
        console.error("TEST-PDF: No open-scan-btn found!");
      }
    }, 1500);
  }

  // ----------------------------------------------------
  // 15.5. User Authentication & Google Sign In
  // ----------------------------------------------------
  const BACKEND_URL = "http://localhost:5000";
  const GOOGLE_CLIENT_ID = "1082051052308-sandbox.apps.googleusercontent.com"; // Sandbox fallback Client ID

  const btnOpenAuth = document.getElementById('btnOpenAuth');
  const authModal = document.getElementById('authModal');
  const closeAuthModal = document.getElementById('closeAuthModal');
  const authModalOverlay = document.getElementById('authModalOverlay');
  const tabSignIn = document.getElementById('tabSignIn');
  const tabRegister = document.getElementById('tabRegister');
  const panelSignIn = document.getElementById('panelSignIn');
  const panelRegister = document.getElementById('panelRegister');
  const formSignIn = document.getElementById('formSignIn');
  const formRegister = document.getElementById('formRegister');
  const authStatusMessage = document.getElementById('authStatusMessage');
  
  // Header Elements
  const headerProfile = document.getElementById('headerProfile');
  const headerAvatar = document.getElementById('headerAvatar');
  const headerUserName = document.getElementById('headerUserName');
  const btnHeaderLogout = document.getElementById('btnHeaderLogout');

  // Toggle modal visibility
  if (btnOpenAuth && authModal) {
    btnOpenAuth.addEventListener('click', () => {
      authModal.classList.add('active');
      resetAuthForm();
    });
  }

  function closeAuth() {
    if (authModal) authModal.classList.remove('active');
  }

  if (closeAuthModal) closeAuthModal.addEventListener('click', closeAuth);
  if (authModalOverlay) authModalOverlay.addEventListener('click', closeAuth);

  // Tab Swap Logic
  if (tabSignIn && tabRegister) {
    tabSignIn.addEventListener('click', () => {
      tabSignIn.classList.add('active');
      tabRegister.classList.remove('active');
      panelSignIn.style.display = 'block';
      panelRegister.style.display = 'none';
      if (authStatusMessage) authStatusMessage.style.display = 'none';
    });

    tabRegister.addEventListener('click', () => {
      tabRegister.classList.add('active');
      tabSignIn.classList.remove('active');
      panelRegister.style.display = 'block';
      panelSignIn.style.display = 'none';
      if (authStatusMessage) authStatusMessage.style.display = 'none';
    });
  }

  function resetAuthForm() {
    if (formSignIn) formSignIn.reset();
    if (formRegister) formRegister.reset();
    if (authStatusMessage) {
      authStatusMessage.style.display = 'none';
      authStatusMessage.textContent = '';
    }
  }

  function showAuthStatus(message, isError = false) {
    if (authStatusMessage) {
      authStatusMessage.style.display = 'block';
      authStatusMessage.style.color = isError ? 'var(--danger)' : 'var(--success)';
      authStatusMessage.textContent = message;
    }
  }

  // Handle standard registration
  if (formRegister) {
    formRegister.addEventListener('submit', async (e) => {
      e.preventDefault();
      const name = document.getElementById('regName').value;
      const email = document.getElementById('regEmail').value;
      const password = document.getElementById('regPassword').value;
      const role = document.getElementById('regRole').value;

      showAuthStatus("Creating profile...");

      try {
        const response = await fetch(`${BACKEND_URL}/signup`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ name, email, password, role })
        });

        const data = await response.json();
        if (response.ok) {
          showAuthStatus("Account created! Please sign in using your credentials.");
          setTimeout(() => {
            if (tabSignIn) {
              tabSignIn.click();
              document.getElementById('loginEmail').value = email;
              document.getElementById('loginPassword').value = password;
            }
          }, 1500);
        } else {
          showAuthStatus(data.message || "Failed to create account.", true);
        }
      } catch (err) {
        console.warn("Backend offline. Simulating registration...");
        showAuthStatus("Account registered (SIMULATOR MODE)! Redirecting...");
        setTimeout(() => {
          if (tabSignIn) {
            tabSignIn.click();
            document.getElementById('loginEmail').value = email;
            document.getElementById('loginPassword').value = password;
          }
        }, 1500);
      }
    });
  }

  // Handle standard login
  if (formSignIn) {
    formSignIn.addEventListener('submit', async (e) => {
      e.preventDefault();
      const email = document.getElementById('loginEmail').value;
      const password = document.getElementById('loginPassword').value;

      showAuthStatus("Authenticating...");

      try {
        const response = await fetch(`${BACKEND_URL}/login`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email, password })
        });

        const data = await response.json();
        if (response.ok) {
          localStorage.setItem('mindscan-token', data.token);
          localStorage.setItem('mindscan-user', JSON.stringify(data.user));
          showAuthStatus("Authenticated successfully!");
          earnXP(50, "Signed into MindScan");
          setTimeout(() => {
            closeAuth();
            updateAuthUI();
          }, 1000);
        } else {
          showAuthStatus(data.message || "Invalid credentials.", true);
        }
      } catch (err) {
        console.warn("Backend offline. Simulating authentication...");
        const mockUser = {
          id: "mock-student-uuid",
          name: email.split('@')[0].replace('.', ' ').replace(/\b\w/g, c => c.toUpperCase()),
          email: email,
          role: "student"
        };
        localStorage.setItem('mindscan-token', 'mock_jwt_token_xxxx');
        localStorage.setItem('mindscan-user', JSON.stringify(mockUser));
        showAuthStatus("Welcome back! (SIMULATOR MODE)");
        earnXP(30, "Signed into MindScan (Offline)");
        setTimeout(() => {
          closeAuth();
          updateAuthUI();
        }, 1000);
      }
    });
  }

  // Google ID Token JWT Decoder
  function decodeGoogleJwt(token) {
    try {
      const base64Url = token.split('.')[1];
      const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
      const jsonPayload = decodeURIComponent(window.atob(base64).split('').map(function(c) {
          return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
      }).join(''));
      return JSON.parse(jsonPayload);
    } catch (e) {
      console.error("Failed to decode Google JWT:", e);
      return null;
    }
  }

  // Handle Google credential token callback
  window.handleGoogleCredentialResponse = async function(response) {
    const credential = response.credential;
    console.log("Google OAuth credential token received");
    
    if (authStatusMessage) {
      authStatusMessage.style.display = 'block';
      authStatusMessage.style.color = 'var(--text-secondary)';
      authStatusMessage.textContent = "Verifying with secure core...";
    }

    try {
      const backendResp = await fetch(`${BACKEND_URL}/google-login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ credential })
      });

      const data = await backendResp.json();
      if (backendResp.ok) {
        localStorage.setItem('mindscan-token', data.token);
        localStorage.setItem('mindscan-user', JSON.stringify(data.user));
        showAuthStatus("Google Sign In verified!");
        earnXP(60, "Connected with Google");
        setTimeout(() => {
          closeAuth();
          updateAuthUI();
        }, 1000);
      } else {
        showAuthStatus(data.message || "Google authentication failed.", true);
      }
    } catch (err) {
      console.warn("Backend offline. Performing client-side OAuth validation...");
      const payload = decodeGoogleJwt(credential);
      if (payload) {
        const mockUser = {
          id: "google-mock-" + payload.sub,
          name: payload.name,
          email: payload.email,
          role: "student",
          picture: payload.picture
        };
        localStorage.setItem('mindscan-token', `mock_google_token_${payload.email}`);
        localStorage.setItem('mindscan-user', JSON.stringify(mockUser));
        showAuthStatus("Welcome back, " + payload.name + "!");
        earnXP(40, "Signed in via Google OAuth (Offline)");
        setTimeout(() => {
          closeAuth();
          updateAuthUI();
        }, 1000);
      } else {
        showAuthStatus("Failed to process Google sign-in credentials.", true);
      }
    }
  };

  // Update UI Elements depending on User State
  function updateAuthUI() {
    const token = localStorage.getItem('mindscan-token');
    const userStr = localStorage.getItem('mindscan-user');

    if (token && userStr) {
      const user = JSON.parse(userStr);
      if (btnOpenAuth) btnOpenAuth.style.display = 'none';
      if (headerProfile) {
        headerProfile.style.display = 'flex';
        if (headerUserName) headerUserName.textContent = user.name.split(' ')[0];
        if (headerAvatar) {
          if (user.picture) {
            headerAvatar.innerHTML = `<img src="${user.picture}" referrerpolicy="no-referrer" style="width:100%; height:100%; border-radius:50%; object-fit:cover;">`;
          } else {
            headerAvatar.textContent = user.name.charAt(0);
          }
        }
      }
      const scanEmail = document.getElementById('scanEmail');
      if (scanEmail) scanEmail.value = user.email;
    } else {
      if (btnOpenAuth) btnOpenAuth.style.display = 'inline-flex';
      if (headerProfile) headerProfile.style.display = 'none';
    }
  }

  // Mobile Navigation Menu Toggle
  const menuToggle = document.getElementById('menuToggle');
  const navMenu = document.getElementById('navMenu');
  if (menuToggle && navMenu) {
    menuToggle.addEventListener('click', () => {
      navMenu.classList.toggle('active');
      menuToggle.classList.toggle('active');
    });

    // Close menu when clicking a link or button
    const navLinks = navMenu.querySelectorAll('a, button');
    navLinks.forEach(link => {
      link.addEventListener('click', () => {
        navMenu.classList.remove('active');
        menuToggle.classList.remove('active');
      });
    });
  }

  // Handle Logout
  if (btnHeaderLogout) {
    btnHeaderLogout.addEventListener('click', () => {
      localStorage.removeItem('mindscan-token');
      localStorage.removeItem('mindscan-user');
      updateAuthUI();
      location.reload();
    });
  }

  // Handle Google Fallback Click
  const btnGoogleFallback = document.getElementById('btnGoogleFallback');
  if (btnGoogleFallback) {
    btnGoogleFallback.addEventListener('click', () => {
      console.log("TEST-AUTH: Google fallback button clicked, simulating response.");
      if (window.handleGoogleCredentialResponse) {
        window.handleGoogleCredentialResponse({
          credential: "mock_google_token_demo.student@university.edu"
        });
      }
    });
  }

  // Initialize UI state
  updateAuthUI();

  // Load and render Google button programmatically
  setTimeout(() => {
    const isSandboxClient = GOOGLE_CLIENT_ID.includes('sandbox');
    let googleRendered = false;
    
    if (isSandboxClient) {
      console.log("TEST-AUTH: Sandbox Client ID detected. Skipping official rendering and loading fallback button directly.");
      const googleBtnDiv = document.getElementById("googleBtnDiv");
      const fallbackBtn = document.getElementById("btnGoogleFallback");
      if (fallbackBtn) {
        fallbackBtn.style.display = "flex";
        if (googleBtnDiv) googleBtnDiv.style.display = "none";
      }
    } else {
      try {
        if (typeof google !== 'undefined' && google.accounts && google.accounts.id) {
          google.accounts.id.initialize({
            client_id: GOOGLE_CLIENT_ID,
            callback: window.handleGoogleCredentialResponse,
            auto_select: false
          });
          google.accounts.id.renderButton(
            document.getElementById("googleBtnDiv"),
            { 
              theme: "outline", 
              size: "large", 
              width: "356",
              shape: "pill",
              logo_alignment: "center"
            }
          );
          googleRendered = true;
        }
      } catch(e) {
        console.warn("Could not render Google Button (Google API offline or blocked):", e);
      }

      // Check if Google button succeeded. If not, show fallback button
      setTimeout(() => {
        const googleBtnDiv = document.getElementById("googleBtnDiv");
        const fallbackBtn = document.getElementById("btnGoogleFallback");
        if (fallbackBtn) {
          if (!googleRendered || !googleBtnDiv || googleBtnDiv.children.length === 0 || googleBtnDiv.innerHTML.trim() === "") {
            fallbackBtn.style.display = "flex";
            if (googleBtnDiv) googleBtnDiv.style.display = "none";
            console.log("TEST-AUTH: Google button rendering failed or empty, showing fallback button.");
          }
        }
      }, 800);
    }
  }, 1000);

  // Automated test helper for auth modal
  if (window.location.search.includes('test-auth')) {
    console.log("TEST-AUTH: Run query parameter detected.");
    // Clear credentials first to ensure a clean login attempt
    localStorage.removeItem('mindscan-token');
    localStorage.removeItem('mindscan-user');
    updateAuthUI();
    
    setTimeout(() => {
      const btn = document.getElementById('btnOpenAuth');
      const modal = document.getElementById('authModal');
      const tabRegister = document.getElementById('tabRegister');
      const formRegister = document.getElementById('formRegister');
      const formSignIn = document.getElementById('formSignIn');
      
      if (btn && modal) {
        console.log("TEST-AUTH: Clicking btnOpenAuth");
        btn.click();
        
        // Wait for modal to open
        setTimeout(() => {
          const isActive = modal.classList.contains('active');
          console.log("TEST-AUTH: Modal active state =", isActive);
          
          if (tabRegister) {
            console.log("TEST-AUTH: Switching to Register tab");
            tabRegister.click();
            
            setTimeout(() => {
              const rand = Math.floor(Math.random() * 1000000);
              const testEmail = `student_${rand}@university.edu`;
              const testPassword = "password123";
              
              document.getElementById('regName').value = "Test Student " + rand;
              document.getElementById('regEmail').value = testEmail;
              document.getElementById('regPassword').value = testPassword;
              document.getElementById('regRole').value = "student";
              
              console.log("TEST-AUTH: Submitting registration form for email:", testEmail);
              formRegister.dispatchEvent(new Event('submit', { cancelable: true, bubbles: true }));
              
              // Wait for registration redirects and switches to Sign In panel
              setTimeout(() => {
                const loginEmailVal = document.getElementById('loginEmail').value;
                const loginPasswordVal = document.getElementById('loginPassword').value;
                console.log("TEST-AUTH: Sign In fields filled:", loginEmailVal === testEmail, loginPasswordVal === testPassword);
                
                console.log("TEST-AUTH: Submitting standard sign-in form");
                formSignIn.dispatchEvent(new Event('submit', { cancelable: true, bubbles: true }));
                
                // Wait for standard sign-in redirect and UI update
                setTimeout(() => {
                  const token = localStorage.getItem('mindscan-token');
                  const user = localStorage.getItem('mindscan-user');
                  console.log("TEST-AUTH: Standard Login success - token =", !!token, "user =", user);
                  
                  // Now test logout
                  console.log("TEST-AUTH: Performing logout simulation");
                  localStorage.removeItem('mindscan-token');
                  localStorage.removeItem('mindscan-user');
                  updateAuthUI();
                  console.log("TEST-AUTH: Logged out successfully");
                  
                  // Click btnOpenAuth again to test Google fallback
                  btn.click();
                  
                  setTimeout(() => {
                    const fallbackBtn = document.getElementById('btnGoogleFallback');
                    if (fallbackBtn) {
                      console.log("TEST-AUTH: Clicking btnGoogleFallback");
                      fallbackBtn.click();
                      
                      setTimeout(() => {
                        const gToken = localStorage.getItem('mindscan-token');
                        const gUser = localStorage.getItem('mindscan-user');
                        console.log("TEST-AUTH: Google Login success - token =", !!gToken, "user =", gUser);
                      }, 2000);
                    } else {
                      console.error("TEST-AUTH: btnGoogleFallback not found!");
                    }
                  }, 1500);
                }, 2000);
              }, 3500);
            }, 1000);
          } else {
            console.error("TEST-AUTH: tabRegister not found!");
          }
        }, 1500);
      } else {
        console.error("TEST-AUTH: btnOpenAuth or authModal not found!");
      }
    }, 1500);
  }
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initializeMindScanApp);
} else {
  initializeMindScanApp();
}
