import json
import uuid
from datetime import datetime
from flask_sqlalchemy import SQLAlchemy
from database.db_interface import DatabaseInterface

db = SQLAlchemy()

# ----------------------------------------------------
# SQLAlchemy Database Models
# ----------------------------------------------------
class UserModel(db.Model):
    __tablename__ = 'users'
    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password = db.Column(db.String(255), nullable=False)
    role = db.Column(db.String(20), nullable=False, default='student') # student, counselor, admin

class SurveyModel(db.Model):
    __tablename__ = 'surveys'
    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id = db.Column(db.String(36), nullable=False)
    survey_type = db.Column(db.String(20), nullable=False) # PHQ-9, GAD-7, PSS
    answers = db.Column(db.Text, nullable=False) # JSON Stringified answers
    score = db.Column(db.Integer, nullable=False)
    timestamp = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)

class MoodModel(db.Model):
    __tablename__ = 'moods'
    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id = db.Column(db.String(36), nullable=False)
    mood = db.Column(db.String(20), nullable=False) # Happy, Neutral, Stressed, Sad, Burnout
    stress_score = db.Column(db.Integer, nullable=False)
    note = db.Column(db.Text, nullable=True)
    timestamp = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)

class AppointmentModel(db.Model):
    __tablename__ = 'appointments'
    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    student_id = db.Column(db.String(36), nullable=False)
    counselor_id = db.Column(db.String(36), nullable=False)
    date = db.Column(db.String(20), nullable=False)
    time_slot = db.Column(db.String(20), nullable=False)
    status = db.Column(db.String(20), nullable=False, default='Pending') # Pending, Approved, Completed
    timestamp = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)


# ----------------------------------------------------
# SQLite Implementation of DatabaseInterface
# ----------------------------------------------------
class SQLiteProvider(DatabaseInterface):
    def __init__(self, app=None):
        if app:
            self.init_app(app)

    def init_app(self, app):
        db.init_app(app)
        with app.app_context():
            db.create_all()
            try:
                from services.security import hash_password
                
                # Seed default student
                student_email = "student@university.edu"
                if not UserModel.query.filter_by(email=student_email).first():
                    student_pwd = hash_password("password123")
                    student_user = UserModel(
                        name="Demo Student", 
                        email=student_email, 
                        password=student_pwd, 
                        role="student"
                    )
                    db.session.add(student_user)
                    print(f"Seeded default student: {student_email}")
                    
                # Seed default counselor
                counselor_email = "counselor@university.edu"
                if not UserModel.query.filter_by(email=counselor_email).first():
                    counselor_pwd = hash_password("password123")
                    counselor_user = UserModel(
                        name="Dr. Sarah Jenkins", 
                        email=counselor_email, 
                        password=counselor_pwd, 
                        role="counselor"
                    )
                    db.session.add(counselor_user)
                    print(f"Seeded default counselor: {counselor_email}")
                    
                db.session.commit()
            except Exception as e:
                print(f"Error seeding database: {e}")

    def save_user(self, name, email, hashed_password, role):
        new_user = UserModel(name=name, email=email, password=hashed_password, role=role)
        db.session.add(new_user)
        db.session.commit()
        return {
            "id": new_user.id,
            "name": new_user.name,
            "email": new_user.email,
            "role": new_user.role
        }

    def get_user_by_email(self, email):
        user = UserModel.query.filter_by(email=email).first()
        if not user:
            return None
        return {
            "id": user.id,
            "name": user.name,
            "email": user.email,
            "password": user.password,
            "role": user.role
        }

    def get_user_by_id(self, user_id):
        user = UserModel.query.get(user_id)
        if not user:
            return None
        return {
            "id": user.id,
            "name": user.name,
            "email": user.email,
            "role": user.role
        }

    def save_survey(self, user_id, survey_type, answers, score):
        new_survey = SurveyModel(
            user_id=user_id,
            survey_type=survey_type,
            answers=json.dumps(answers),
            score=score
        )
        db.session.add(new_survey)
        db.session.commit()
        return {
            "id": new_survey.id,
            "user_id": new_survey.user_id,
            "survey_type": new_survey.survey_type,
            "score": new_survey.score,
            "timestamp": new_survey.timestamp.isoformat()
        }

    def get_surveys_by_user(self, user_id):
        surveys = SurveyModel.query.filter_by(user_id=user_id).order_by(SurveyModel.timestamp.desc()).all()
        return [
            {
                "id": s.id,
                "user_id": s.user_id,
                "survey_type": s.survey_type,
                "answers": json.loads(s.answers),
                "score": s.score,
                "timestamp": s.timestamp.isoformat()
            } for s in surveys
        ]

    def save_mood(self, user_id, mood, stress_score, note):
        new_mood = MoodModel(
            user_id=user_id,
            mood=mood,
            stress_score=stress_score,
            note=note
        )
        db.session.add(new_mood)
        db.session.commit()
        return {
            "id": new_mood.id,
            "user_id": new_mood.user_id,
            "mood": new_mood.mood,
            "stress_score": new_mood.stress_score,
            "note": new_mood.note,
            "timestamp": new_mood.timestamp.isoformat()
        }

    def get_mood_history(self, user_id):
        moods = MoodModel.query.filter_by(user_id=user_id).order_by(MoodModel.timestamp.desc()).all()
        return [
            {
                "id": m.id,
                "user_id": m.user_id,
                "mood": m.mood,
                "stress_score": m.stress_score,
                "note": m.note,
                "timestamp": m.timestamp.isoformat()
            } for m in moods
        ]

    def save_appointment(self, student_id, counselor_id, date, time_slot):
        new_appt = AppointmentModel(
            student_id=student_id,
            counselor_id=counselor_id,
            date=date,
            time_slot=time_slot,
            status='Pending'
        )
        db.session.add(new_appt)
        db.session.commit()
        return {
            "id": new_appt.id,
            "student_id": new_appt.student_id,
            "counselor_id": new_appt.counselor_id,
            "date": new_appt.date,
            "time_slot": new_appt.time_slot,
            "status": new_appt.status,
            "timestamp": new_appt.timestamp.isoformat()
        }

    def get_appointments_by_user(self, user_id, role):
        if role == 'student':
            appts = AppointmentModel.query.filter_by(student_id=user_id).order_by(AppointmentModel.timestamp.desc()).all()
        elif role == 'counselor':
            appts = AppointmentModel.query.filter_by(counselor_id=user_id).order_by(AppointmentModel.timestamp.desc()).all()
        else:
            appts = AppointmentModel.query.order_by(AppointmentModel.timestamp.desc()).all()

        results = []
        for a in appts:
            student = UserModel.query.get(a.student_id)
            counselor = UserModel.query.get(a.counselor_id)
            results.append({
                "id": a.id,
                "student_id": a.student_id,
                "student_name": student.name if student else "Unknown Student",
                "counselor_id": a.counselor_id,
                "counselor_name": counselor.name if counselor else "Unknown Counselor",
                "date": a.date,
                "time_slot": a.time_slot,
                "status": a.status,
                "timestamp": a.timestamp.isoformat()
            })
        return results

    def update_appointment_status(self, appointment_id, status):
        appt = AppointmentModel.query.get(appointment_id)
        if not appt:
            return None
        appt.status = status
        db.session.commit()
        return {
            "id": appt.id,
            "status": appt.status
        }

    def get_admin_analytics(self):
        total_surveys = SurveyModel.query.count()
        total_users = UserModel.query.count()
        total_students = UserModel.query.filter_by(role='student').count()
        
        # High risk students are those who have a GAD-7 score > 15 (Severe) or PHQ-9 > 15 in their latest survey
        # We can simulate/aggregate this quickly
        high_risk_count = 0
        students = UserModel.query.filter_by(role='student').all()
        for student in students:
            latest_survey = SurveyModel.query.filter_by(user_id=student.id).order_by(SurveyModel.timestamp.desc()).first()
            if latest_survey:
                # GAD-7 max possible is 21. If raw GAD-7 score represents severity, PHQ-9 max is 27.
                # Since scores saved might be raw or percentage, if percent score is > 70% or raw score > 14
                if latest_survey.score > 14: # Assuming raw score threshold
                    high_risk_count += 1

        # Mood analytics
        all_moods = MoodModel.query.all()
        mood_counts = {}
        for m in all_moods:
            mood_counts[m.mood] = mood_counts.get(m.mood, 0) + 1

        # Appointment statistics
        total_appts = AppointmentModel.query.count()
        pending_appts = AppointmentModel.query.filter_by(status='Pending').count()
        approved_appts = AppointmentModel.query.filter_by(status='Approved').count()
        completed_appts = AppointmentModel.query.filter_by(status='Completed').count()

        return {
            "total_surveys": total_surveys,
            "total_users": total_users,
            "total_students": total_students,
            "high_risk_students": high_risk_count,
            "mood_analytics": mood_counts,
            "appointments": {
                "total": total_appts,
                "pending": pending_appts,
                "approved": approved_appts,
                "completed": completed_appts
            }
        }
